/*
 *Copyright 1993-2003.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Educational institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */

#ifdef OSX_CARBON
#include <Carbon/Carbon.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "interface.h"
#include "osx/main.h"

/* Constants */
const Rect resize_bounds = { 200,200,16000,16000};
const Rect big_rect = { 0, 0, 16000, 16000};

/* Structs */
typedef struct {
    display_data parent;
    WindowPtr mainwin;
    DialogPtr parm_dialog;
    int parm_last;
    int last;
    int loop;
    char *filename;
} mac_display_data; 

typedef struct {
    graphics_context parent; 
    WindowPtr win;
    int xoffset;
    int yoffset;
} mac_graphics_context;

/* prototypes */
static void setup_callbacks(mac_display_data *dd);
static void mac_create_main_window(mac_display_data *dd,int width, int height);
static void mac_start(mac_display_data *dd);
static void setup_menus(mac_display_data *dd);
static unsigned char* c_to_p(char *str);
static void handle_menu(mac_display_data *dd,int menu);
static void handle_resize(mac_display_data *dd,EventRecord ev);
static void mac_line(mac_graphics_context *gc, int x1, int y1, int x2, int y2);
static void setup_main_gc(mac_display_data *dd,int width, int height);
static void paint_mainwin(mac_display_data *dd);
static void mac_clear_display(mac_graphics_context *gc);
static void mac_line(mac_graphics_context *gc, int x1, int y1, int x2, int y2);
static int mac_get_parms(mac_display_data *dd);
static void paint_dialog(WindowPtr dlg);
static void setup_parm_dialog(mac_display_data *dd);
static void do_dlg_mouse_click(mac_display_data *dd,EventRecord ev,int where, WindowPtr win);


static void p_to_c(char *buf) 
{
	int i,j;
	
	j=buf[0];
	for ( i = 0 ; i < j ; i++)
		buf[i] = buf[i+1];
	buf[i]=j;
}

static void retrieve_parms(mac_display_data *dd)
{
	int i,controlnum,nullskipper = 0;
	char buffer[255];
	Handle h;
	short item_type;
	Rect r;

	for ( i=0 ; i < NUM_PARMS ; i++) {
		if (dd->parent.parms[i].label == NULL) {
			nullskipper++;
			continue;
		}
		controlnum = (i-nullskipper+1) * 2;
		GetDialogItem(dd->parm_dialog,controlnum,&item_type,&h,&r);
		GetDialogItemText(h,(unsigned char*)buffer);
		p_to_c(buffer);
		if (dd->parent.parms[i].type == P_LONG)
			dd->parent.parms[i].data = atoi(buffer);
		else
			dd->parent.parms[i].data = atof(buffer);
	}
}


static void paint_dialog(WindowPtr dlg) 
{
	BeginUpdate(dlg);
#ifdef OSX_CARBON
	UpdateDialog(GetDialogFromWindow(dlg),
               GetPortVisibleRegion(GetWindowPort(dlg), NULL));
#else
	UpdateDialog(dlg, dlg->visRgn);
#endif
	EndUpdate(dlg);
}

static void handle_dlg_event(mac_display_data *dd,WindowPtr dlg)
{ 
	EventRecord ev;
	int ok,where;
	WindowPtr win;
#ifdef OSX_CARBON 
	DialogPtr winDlg;
#endif
	short item;
	char key;

	dd->loop = 1;
	while (dd->loop == 1) {
#ifdef OSX_CARBON
    ok = WaitNextEvent (everyEvent, &ev, 0x7FFFFFFF, NULL);
#else
		ok = GetNextEvent(everyEvent,&ev);
#endif
		where = FindWindow(ev.where,&win);
		if (ok == 0){
#ifdef OSX_CARBON
			winDlg = GetDialogFromWindow(win);
			DialogSelect(&ev,&winDlg,&item); 
			win = GetDialogWindow(winDlg);
#else
      DialogSelect(&ev,&win,&item);
#endif
		}
		if (ev.what == mouseDown && win == dlg) 
			do_dlg_mouse_click(dd,ev,where,dlg);
		else if (ev.what == updateEvt && win == dlg) 
			paint_dialog(dlg);
		else if (ev.what == updateEvt && win == dd->mainwin)
			paint_mainwin(dd);
		else if (ev.what == keyDown) {
			key = (char)(ev.message & charCodeMask);
			if ( key == '\r' ) {
				HideWindow(dlg);
				dd->loop = 0;
			} else {
#ifdef OSX_CARBON
        winDlg = GetDialogFromWindow(dlg);
        DialogSelect(&ev,&winDlg,&item);
        dlg = GetDialogWindow(winDlg);
#else
        DialogSelect(&ev,&dlg,&item);
#endif
			}
		} else { 
#ifdef OSX_CARBON
			winDlg = GetDialogFromWindow(dlg);
      DialogSelect(&ev,&winDlg,&item);
      dlg = GetDialogWindow(winDlg);
#else
      DialogSelect(&ev,&dlg,&item);
#endif
		}
	}		
}

static int mac_get_parms(mac_display_data *dd)
{
#ifdef OSX_CARBON
	WindowPtr winPtr;
  if (dd->parm_dialog != NULL){
    DisposeDialog(dd->parm_dialog);
    dd->parm_dialog = NULL;
  } 
  setup_parm_dialog(dd);
	winPtr = GetDialogWindow(dd->parm_dialog);
	ShowWindow(winPtr);
	SelectWindow(winPtr);
	paint_dialog(winPtr);
	dd->last = dd->parm_last;
	handle_dlg_event(dd,winPtr);
#else
  if (dd->parm_dialog != NULL){
    DisposeDialog(dd->parm_dialog);
    dd->parm_dialog = NULL;
  } 
  setup_parm_dialog(dd);
  ShowWindow(dd->parm_dialog);
  SelectWindow(dd->parm_dialog);
  paint_dialog(dd->parm_dialog);
	dd->last = dd->parm_last;
  handle_dlg_event(dd,dd->parm_dialog);
#endif
	retrieve_parms(dd);
	return 1;
}

static void setup_parm_dialog(mac_display_data *dd)
{
	unsigned char *tmp;
	Handle text,buttons;
	int i,nullskipper=0,controlnum;
	short item_type;
	Handle h;
	Rect r;
	char buffer[100];


	tmp = c_to_p("Settings");
	dd->parm_dialog = GetNewDialog(130,NULL,(void*)-1);
	text = GetResource('DITL',128);
	for (i = 0 ; i < NUM_PARMS ; i++) {
		if (dd->parent.parms[i].label == NULL) {
			nullskipper++;
			continue;
		}
		AppendDITL(dd->parm_dialog,text,appendDITLBottom);
		controlnum = (i-nullskipper) * 2 +1;
		GetDialogItem(dd->parm_dialog,controlnum,&item_type,&h,&r);
		tmp = c_to_p(dd->parent.parms[i].label);
		SetDialogItemText(h,tmp);
		free(tmp);
		controlnum++;
		GetDialogItem(dd->parm_dialog,controlnum,&item_type,&h,&r);
		sprintf(buffer,"%g",dd->parent.parms[i].data);
		tmp = c_to_p(buffer);
		SetDialogItemText(h,tmp);
		free(tmp);
	}
	
	dd->parm_last = (i-nullskipper) * 2 + 1;
	buttons = GetResource('DITL',129);
	AppendDITL(dd->parm_dialog,buttons,appendDITLBottom);
}

static void paint_mainwin(mac_display_data *dd)
{
    BeginUpdate(dd->mainwin);
#ifdef OSX_CARBON
    SetPort(GetWindowPort(dd->mainwin));
#else
    SetPort((void*)dd->mainwin);
#endif
    EraseRect(&big_rect);
    PenSize(1,1);
    draw_graph((graphics_context *)(dd->parent.gc),dd->parent.parms,dd->parent.run);
    EndUpdate(dd->mainwin);
}

static void handle_resize(mac_display_data *dd,EventRecord ev)
{
    long windowsize;
    windowsize = GrowWindow(dd->mainwin,ev.where,&resize_bounds);
    if (windowsize != 0) {
        SizeWindow(dd->mainwin,LoWord(windowsize),HiWord(windowsize),TRUE);
	dd->parent.gc->width = LoWord(windowsize);
	dd->parent.gc->height = HiWord(windowsize);
#ifdef OSX_CARBON
  InvalWindowRect(dd->mainwin, &big_rect);
#else
	InvalRect(&big_rect);
#endif
    }
}


static void handle_menu(mac_display_data *dd,int menu)
{
   int m = HiWord(menu);
   int i = LoWord(menu);
   if (dd->parent.app_menu->num_menus >= m && m >= 0 &&
           dd->parent.app_menu->menus[m-1].num_items >= i && i > 0)
           if (dd->parent.app_menu->menus[m-1].items[i-1].callback != NULL)
		       dd->parent.app_menu->menus[m-1].items[i-1].callback((display_data*)dd);
   HiliteMenu(0);
}

static unsigned char* c_to_p(char *str) 
{
    unsigned char* ret;
    ret = malloc(strlen(str) + 2);
    ret[0] = strlen(str);
    strcpy((char *)ret + 1,str);
    return ret;
}

static unsigned char* escape_menu_string(menuitem *m)
{
	unsigned char* ret;
	int i,j;

	ret = malloc(strlen(m->label)*2 + 4);

	ret++;
	for ( i = 0, j = 0 ; i < strlen(m->label) ; i++,j++) {
		if (m->label[i] == '/' ) {
			ret[j] = '\\'; /* There should be a better way to escape a / */
			continue;
		}
		ret[j] = m->label[i];
	}
	ret[j] = '/';
	ret[j+1] = m->accelerator;
	ret[j+2] = 0;
	*(ret - 1) = strlen((char*)ret);
	ret--;
	return ret;
}

static void enable_disable_menus(menubar *mbar) 
{
	int i;
	int j;
	MenuHandle mh;

	for ( i = 0 ;  i < mbar->num_menus ; i++ ) {
		mh = GetMenuHandle(i+1);
		for ( j = 0 ;  j < mbar->menus[i].num_items ; j++ ) {
#ifdef OSX_CARBON
			if (mbar->menus[i].items[j].enabled == TRUE)	
				EnableMenuItem(mh,j+1);
			else
				DisableMenuItem(mh,j+1);
#else				
			if (mbar->menus[i].items[j].enabled == TRUE)	
				EnableItem(mh,j+1);
			else
				DisableItem(mh,j+1);
#endif
		}
	}
    	DrawMenuBar();
}


static void setup_menus(mac_display_data *dd) 
{   
	MenuRef m;
	unsigned char *tmp;
	int i,j,k=0;
	Handle m_bar;
	menubar *app_menu = dd->parent.app_menu;
	m_bar = GetNewMBar(128);
	SetMenuBar(m_bar);
   
	for ( i = 0 ; i < app_menu->num_menus ; i++) {
		tmp = c_to_p(app_menu->menus[i].label);
		m = NewMenu(i + 1,tmp);
		free(tmp);
		for ( j = 0 ; j < app_menu->menus[i].num_items ; j++) {
			tmp = escape_menu_string(&(app_menu->menus[i].items[j]));
			AppendMenu(m,tmp);
			free(tmp);
			SetItemCmd(m,i-1,app_menu->menus[i].items[j].accelerator);
		}
		InsertMenu(m,0);
	}
	AppendResMenu(GetMenuHandle(128) , 'DRVR');
	enable_disable_menus(app_menu);
	DrawMenuBar();
}


static void do_mainwin_mouse_click(mac_display_data *dd,EventRecord ev,int where)
{
	if (where == inGoAway) {
		if ( TrackGoAway (dd->mainwin, ev.where))
			HideWindow(dd->mainwin);
	}
	else if (where == inDrag)
		DragWindow(dd->mainwin, ev.where, &big_rect);
	else if (where == inGrow)
		handle_resize(dd,ev);
#ifndef OSX_CARBON
	else if (where == inSysWindow)
		SystemClick(&ev,dd->mainwin);
#endif
	else if (where == inMenuBar)
		handle_menu(dd,MenuSelect(ev.where));
}

static void do_dlg_mouse_click(mac_display_data *dd,EventRecord ev,int where,WindowPtr win)
{
#ifdef OSX_CARBON
	DialogPtr tmpDlg;
#endif
	short item;
	if (where == inSysWindow) {
#ifndef OSX_CARBON
		SystemClick(&ev,win);
    DialogSelect(&ev,&win,&item);
#else
		tmpDlg = GetDialogFromWindow(win);
		DialogSelect(&ev,&tmpDlg,&item); 
#endif
	}
	else if (where == inDrag)
		DragWindow(win, ev.where, &big_rect);
	else {
#ifdef OSX_CARBON
		tmpDlg = GetDialogFromWindow(win);
		DialogSelect(&ev,&tmpDlg,&item);
		win = GetDialogWindow(tmpDlg); 
#else
    DialogSelect(&ev,&win,&item);
#endif
		if (item == dd->last) {
			HideWindow(win);
			dd->loop = 0;
		}
	}
}

static double mac_rand() 
{
	return (((double)rand())/RAND_MAX);
}

static void handle_key_down(mac_display_data *dd, EventRecord *ev)
{
	char key;
	int i,j;
	menubar *app_menu = dd->parent.app_menu;

	key = (char)(ev->message & charCodeMask);
	if ( ev->modifiers & cmdKey ) {
		for ( i = 0 ; i < app_menu->num_menus ; i++) {
			for ( j = 0 ; j < app_menu->menus[i].num_items ; j++) {
				if ( toupper(app_menu->menus[i].items[j].accelerator) == toupper(key) && 
						app_menu->menus[i].items[j].enabled)
					app_menu->menus[i].items[j].callback((display_data*)dd);
			}
		}
	}
}

static void mac_start(mac_display_data *dd)
{
	EventRecord ev;
	int ok,where;
	WindowPtr win;

	while (true) {
#ifdef OSX_CARBON
    ok = WaitNextEvent(everyEvent, &ev, 0x7FFFFFFF, NULL);
    if(!ok) return;
#else
		ok = GetNextEvent(everyEvent,&ev);
#endif
		if (dd->filename) {
			fixmacfile(dd->filename);
			dd->filename = NULL;
		}
		where = FindWindow(ev.where,&win);
		if (ev.what == updateEvt)
			paint_mainwin(dd);
		else if (ev.what == mouseDown)
			do_mainwin_mouse_click(dd,ev,where);
#ifndef OSX_CARBON
		else if (ev.what == mouseDown && where == inSysWindow)
			SystemClick(&ev,win);
#endif
		else if (ev.what == mouseDown && where == inMenuBar)
			handle_menu(dd,MenuSelect(ev.where));
		else if (ev.what == keyDown) {
			handle_key_down(dd,&ev);
		}
	}

}

static void mac_line(mac_graphics_context *gc, int x1, int y1, int x2, int y2)
{
#ifdef OSX_CARBON
  if(gc->win)
    SetPort(GetWindowPort(gc->win));
#else
	SetPort((GrafPtr)gc->win);
#endif
	MoveTo(x1 + gc->xoffset,y1 + gc->yoffset);
	LineTo(x2 + gc->xoffset,y2 + gc->yoffset);
}

static void mac_out_text(mac_graphics_context *gc, int x, int y, char* text)
{
	unsigned char *tmp;
#ifdef OSX_CARBON
  if(gc->win)
    SetPort(GetWindowPort(gc->win));
#else
  SetPort((GrafPtr)gc->win);
#endif
	MoveTo(x + gc->xoffset,y + gc->yoffset);
	tmp = c_to_p(text);
	DrawString(tmp);
	free(tmp);
}

static int mac_string_width(mac_graphics_context *gc, char* string)
{
    unsigned char *tmp;
    int i;
#ifdef OSX_CARBON
    if(gc->win)
      SetPort(GetWindowPort(gc->win));
#else
    SetPort((GrafPtr)gc->win);
#endif
    tmp = c_to_p(string);
    i = StringWidth(tmp);
    free(tmp);
    return i;
}

static void mac_clear_display(mac_graphics_context *gc)
{
#ifdef OSX_CARBON
  if(gc->win)
    SetPort(GetWindowPort(gc->win));
  else
    return;
#else
	SetPort((GrafPtr)gc->win);
#endif
	EraseRect(&big_rect);
}

static void mac_flush(mac_graphics_context *gc)
{
	if (gc->xoffset == 0) {
#ifdef OSX_CARBON
    CGrafPtr port = GetWindowPort(gc->win);
    RgnHandle visRgn = GetPortVisibleRegion(port, 0);
    QDFlushPortBuffer(port, visRgn); 
#endif
		ShowWindow(gc->win);
		SelectWindow(gc->win);
	}
}

static void setup_main_gc(mac_display_data *dd, int width, int height) 
{
    mac_graphics_context *gc;

    gc = malloc (sizeof(mac_graphics_context));
    gc->win = dd->mainwin;
    gc->parent.height = height;
    gc->parent.width = width;
    gc->parent.half_text_height = 6;
    gc->parent.line = (line_t)mac_line;
    gc->parent.out_text = (out_text_t)mac_out_text;
    gc->parent.clear_display = (clear_display_t)mac_clear_display;
    gc->parent.flush = (flush_t)mac_flush;
    gc->parent.string_width = (string_width_t)mac_string_width;
    gc->xoffset = 0;
    gc->yoffset = 0;
    dd->parent.gc = (graphics_context*)gc;
}

static void mac_create_main_window(mac_display_data *dd,int width, int height)
{
    unsigned char *tmp;
    Rect gfxBounds = {50,10,400,260};
    gfxBounds.bottom= height + 50;
    gfxBounds.right= width + 10;
    
    tmp = c_to_p("PopG");
    dd->mainwin = NewCWindow (NULL,&gfxBounds, tmp, 0, documentProc,
            (WindowPtr) - 1L, true, 0);
    free(tmp);
    setup_main_gc(dd,width,height);
    ShowWindow(dd->mainwin);
    SelectWindow(dd->mainwin);
#ifdef OSX_CARBON
    InvalWindowRect(dd->mainwin ,&big_rect);
#else
    InvalRect(&big_rect);
#endif
    setup_menus(dd); 
}

static char* mac_get_user_input(mac_display_data *dd,char *title, char *message, char *def)
{
	WindowPtr dlg;
#ifdef OSX_CARBON
	DialogPtr tmpDlg;
#endif
	unsigned char *tmp;
	Handle h;
	short item_type;
	Rect r;
	char buffer[100];

#ifdef OSX_CARBON
	dlg = GetDialogWindow(GetNewDialog(131,NULL,(void*)-1));
#else
  dlg = GetNewDialog(131,NULL,(void*)-1);
#endif
	dd->last = 3;
	
	tmp=c_to_p(title);
	SetWTitle(dlg,tmp);
	free(tmp);

#ifdef OSX_CARBON
	tmpDlg = GetDialogFromWindow(dlg);
	GetDialogItem(tmpDlg,1,&item_type,&h,&r);
#else
  GetDialogItem(dlg,1,&item_type,&h,&r);
#endif
	tmp = c_to_p(message);
	SetDialogItemText(h,tmp);
	free(tmp);	

#ifdef OSX_CARBON
	GetDialogItem(tmpDlg,2,&item_type,&h,&r);
#else
  GetDialogItem(dlg,2,&item_type,&h,&r);
#endif
	tmp = c_to_p(def);
	SetDialogItemText(h,tmp);
	free(tmp);	


	ShowWindow(dlg);
	SelectWindow(dlg);
	paint_dialog(dlg);
	handle_dlg_event(dd,dlg);

#ifdef OSX_CARBON
	GetDialogItem(tmpDlg,2,&item_type,&h,&r);
#else
  GetDialogItem(dlg,2,&item_type,&h,&r);
#endif
	GetDialogItemText(h,(unsigned char*)buffer);

	buffer[buffer[0] + 1] = 0;

	return (char*)strdup(buffer + 1);
}

static void mac_show_message(mac_display_data *dd,char* message) 
{
#ifdef OSX_CARBON
	WindowPtr win;
	DialogPtr dlg;
#else
  WindowPtr dlg;
#endif
	unsigned char *tmp;
	Handle h;
	short item_type;
	Rect r;
	
	if (strlen(message) > 255) {
		dlg = GetNewDialog(133,NULL,(void*)-1);
	}
	else {
		dlg = GetNewDialog(132,NULL,(void*)-1);
		GetDialogItem(dlg,1,&item_type,&h,&r);
		tmp = c_to_p(message);
		SetDialogItemText(h,tmp);
		free(tmp);	
	}
#ifdef OSX_CARBON
	win = GetDialogWindow(dlg);
	ShowWindow(win);
	SelectWindow(win);
	paint_dialog(win);
	dd->last = 2;
	handle_dlg_event(dd,win);
#else
  ShowWindow(dlg);
  SelectWindow(dlg);
  paint_dialog(dlg);
  dd->last = 2;
  handle_dlg_event(dd,dlg);
#endif
}

static void mac_print(mac_display_data *dd)
{
#ifdef OSX_CARBON
	PMPageFormat pageFormat = kPMNoPageFormat;
	PMPrintSettings printSettings = kPMNoPrintSettings;
  PMPrintSession printSession;
  OSStatus status;
  Boolean printAccept;
  
  status = PMCreateSession(&printSession);
  if(status){
    /* error */
    return;
  }
  status = PMCreatePrintSettings(&printSettings);
  if ((status == noErr) && (printSettings != kPMNoPrintSettings))
		status = PMSessionDefaultPrintSettings(printSession, printSettings);
  status = PMCreatePageFormat(&pageFormat);
  if(status==noErr)
    status = PMSessionDefaultPageFormat(printSession, pageFormat);
  PMSessionPrintDialog(printSession, printSettings, pageFormat, &printAccept);

  if(printAccept){
    GrafPtr origPort, printPort;
    mac_graphics_context gc;
    PMRect tempPageRect;

    PMSessionBeginDocument(printSession, printSettings, pageFormat);
    PMSessionBeginPage(printSession, pageFormat, NULL);

    /* setup graphics context for drawing to page */
    status = PMGetAdjustedPageRect(pageFormat, &tempPageRect);
    GetPort(&origPort);
    status = PMSessionGetGraphicsContext(printSession, kPMGraphicsContextQuickdraw, 
                                         (void**) &printPort);
    SetPort(printPort);
    gc.win = NULL;
    gc.xoffset = tempPageRect.left;
    gc.yoffset = tempPageRect.top;
    gc.parent.width = tempPageRect.right - gc.xoffset ;
    gc.parent.height = tempPageRect.bottom - gc.yoffset ;
    gc.parent.half_text_height = 6;
    gc.parent.line = (line_t)mac_line;
    gc.parent.out_text = (out_text_t)mac_out_text;
    gc.parent.clear_display = (clear_display_t)mac_clear_display;
    gc.parent.flush = (flush_t)mac_flush;
    gc.parent.string_width = (string_width_t)mac_string_width;

    draw_graph((graphics_context *)(&gc),dd->parent.parms,dd->parent.run);
    
    /* reset port back to main window */
    SetPort(origPort);
    PMSessionEndPage(printSession);
    PMSessionEndDocument(printSession);
  }
  /* cleanup */
  PMRelease(printSession);
  PMRelease(printSettings);
  PMRelease(pageFormat);

#else
	THPrint prhandle;
	mac_graphics_context gc;

	prhandle = (THPrint)NewHandleClear(sizeof(TPrint));

	if (prhandle == NULL)
		return;
	
	PrintDefault(prhandle);
  
	PrOpen();
  	if (PrJobDialog(prhandle) == FALSE) {
		PrClose();
		return;
	}
	else if (PrStlDialog(prhandle) == FALSE) {
		PrClose();
		return;
	}

	gc.win =(GrafPort*) PrOpenDoc(prhandle,NULL,NULL);	
	
	PrOpenPage((TPrPort*)gc.win,NULL);
	gc.xoffset = (*prhandle)->prInfo.rPage.left;
	gc.yoffset = (*prhandle)->prInfo.rPage.top;
  gc.parent.width = (*prhandle)->prInfo.rPage.right - gc.xoffset ;
	gc.parent.height = (*prhandle)->prInfo.rPage.bottom - gc.yoffset ;
	gc.parent.half_text_height = 6;
	gc.parent.line = (line_t)mac_line;
	gc.parent.out_text = (out_text_t)mac_out_text;
	gc.parent.clear_display = (clear_display_t)mac_clear_display;
	gc.parent.flush = (flush_t)mac_flush;

  draw_graph((graphics_context *)(&gc),dd->parent.parms,dd->parent.run);
	PrClosePage((TPrPort*)gc.win);
	PrCloseDoc((TPrPort*)gc.win);
	PrClose();
#endif
}

void fixmacfile(char* filename)
{
	FInfo  fndrinfo;
#ifdef OSX_CARBON
  FSSpec fileSpec;
  FSRef fileRef;
  FSPathMakeRef((unsigned char *)filename, &fileRef, NULL);
  FSGetCatalogInfo(&fileRef, kFSCatInfoNone, NULL, NULL, &fileSpec, NULL);
  FSpGetFInfo(&fileSpec, &fndrinfo);
  fndrinfo.fdType='TEXT';
  fndrinfo.fdCreator='vgrd';
  FSpSetFInfo(&fileSpec, &fndrinfo);
#else
	char filename1[100];
	char filename2[100];

	strcpy(filename1,filename);
	strcpy(filename2,filename);
	GetFInfo(CtoPstr(filename1),0,&fndrinfo);
	fndrinfo.fdType='TEXT';
	fndrinfo.fdCreator='vgrd';
	SetFInfo(CtoPstr(filename2),0,&fndrinfo);
#endif
}


static char* mac_get_save_filename(mac_display_data *dd,char *title,char* def)
{
#ifdef OSX_CARBON
  NavDialogCreationOptions	dialogOptions;
  NavDialogRef outDialog;
	OSStatus theErr = noErr;
  char *fileName = NULL;

  NavGetDefaultDialogCreationOptions( &dialogOptions );
  dialogOptions.clientName = CFStringCreateWithPascalString( NULL, LMGetCurApName(), GetApplicationTextEncoding());
  dialogOptions.saveFileName = CFStringCreateWithCString(NULL, def, GetApplicationTextEncoding());
  dialogOptions.windowTitle = CFStringCreateWithCString(NULL, title, GetApplicationTextEncoding());

	theErr = NavCreatePutFileDialog( &dialogOptions, 'TEXT', 'vgrd',
                                    NULL, NULL, &outDialog );

  if ( theErr == noErr ){
		theErr = NavDialogRun( outDialog );
		if(theErr == noErr){
      NavReplyRecord outReply;
      FSRef dirRef;
      AEDesc dirDesc;
      AEKeyword theAEKeyword;
      char dirTemp[256], fileTemp[100];

			theErr = NavDialogGetReply(outDialog, &outReply);
      if(theErr){
        NavDialogDispose(outDialog);
        NavDisposeReply(&outReply);
        return NULL;
      }
      CFStringGetCString( outReply.saveFileName, fileTemp, 100, GetApplicationTextEncoding());
      theErr = AEGetNthDesc(&outReply.selection, 1, typeFSRef, &theAEKeyword ,&dirDesc);
      if(theErr == noErr){
        AEGetDescData(&dirDesc, &dirRef, sizeof(dirRef));
        FSRefMakePath(&dirRef, dirTemp, 100);
        strcat(dirTemp, "/");
        strncat(dirTemp, fileTemp, 100-strlen(fileTemp)-1);
        fileName = strdup(dirTemp);
      }
      NavDisposeReply(&outReply);
		}
    NavDialogDispose( outDialog );
  }
  dd->filename = fileName;
	return fileName;
#else
	StandardFileReply sfr;
	unsigned char *tmp, *tmp1;
	char buffer[100];

	tmp = c_to_p(def);
	tmp1 = c_to_p("Enter File Name to save as");
	StandardPutFile(tmp1,tmp,&sfr);
	free(tmp);
	free(tmp1);
	if (sfr.sfGood == FALSE)
		return NULL;
	tmp = sfr.sfFile.name;
	strncpy(buffer,(void*)(tmp + 1),tmp[0]);
	buffer[tmp[0]] = 0;
	dd->filename = (char*)strdup(buffer);
	return ((char*)strdup(buffer));
#endif
}

static void mac_enable_menuitem(mac_display_data *dd,menuitem *m)
{
	m->enabled = TRUE;
	enable_disable_menus(dd->parent.app_menu);	
}

static void change_menuitem_text(mac_display_data *dd,menuitem *m)
{
	int i,j;
	menubar *app_menu = dd->parent.app_menu;
	MenuHandle mh;
	unsigned char * tmp;

	for ( i = 0 ; i < app_menu->num_menus ; i++ ) {
		for ( j = 0 ; j < app_menu->menus[i].num_items ; j++) {
			if ( &(app_menu->menus[i].items[j]) == m)
				break;
		}
		if ( &(app_menu->menus[i].items[j]) == m)
			break;
	}
	mh = GetMenuHandle(i+1);
	tmp = c_to_p(m->label);
	SetMenuItemText(mh,j+1,tmp);
	free(tmp);
}

static void setup_callbacks(mac_display_data *dd)
{
	dd->parent.rand= (rand_t)mac_rand;
	dd->parent.create_main_window = (create_main_window_t)mac_create_main_window;
	dd->parent.start = (start_t)mac_start;
	dd->parent.get_parms=(get_parms_t)mac_get_parms;
	dd->parent.enable_menuitem = (enable_menuitem_t)mac_enable_menuitem;
	dd->parent.change_menuitem_text = (change_menuitem_text_t)change_menuitem_text;
	dd->parent.get_user_input = (get_user_input_t)mac_get_user_input;
	dd->parent.get_save_file_name = (get_save_file_name_t)mac_get_save_filename;
	dd->parent.show_message = (show_message_t)mac_show_message;
	dd->parent.print = (print_t)mac_print;
}


#ifdef OSX_CARBON
static OSErr QuitAppleEventHandler( const AppleEvent *appleEvt, AppleEvent* reply, UInt32 refcon )
{
  exit(0);
  return noErr;
}
#endif


display_data* init_ui(int argc,char **argv)
{ 
	mac_display_data *dd;

#ifndef OSX_CARBON
	InitGraf(&(qd.thePort));
	InitFonts();
	InitWindows();
	InitMenus();
	InitDialogs(NULL);
	TEInit();
#endif
	InitCursor();
	dd = calloc(1,sizeof(mac_display_data));
	dd->parm_dialog=NULL;
	dd->filename=NULL;
	setup_callbacks(dd);
#ifdef OSX_CARBON
  AEInstallEventHandler( kCoreEventClass, kAEQuitApplication, NewAEEventHandlerUPP((AEEventHandlerProcPtr)QuitAppleEventHandler), 0, false );
#endif

	srand(time(NULL));

	return (display_data *)dd;
}
