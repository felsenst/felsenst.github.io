/*
 *Copyright 1993-2003.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Educational institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */


#include "popg.h"
#include <stdio.h>

typedef struct {
    graphics_context parent;
    FILE *file;
} p_graphics_context;

void write_postscript_file(char * file_name,parameter *parms, run_data* run);
void write_prolog(p_graphics_context *gc,char *title);
void write_footer(p_graphics_context *gc);
void setup_pgc(p_graphics_context *gc);

