/* 
 *Copyright 1993-2003.  University of Washington and Joseph Felsenstein.  All 
 *rights reserved.  Permission is granted to reproduce, perform, and modify 
 *this program.  Permission is granted to distribute or provide access to this 
 *program provided that this copyright notice is not removed, this program is 
 *not integrated with or called by any product or service that generates 
 *revenue, and that your distribution of this program is free.  Any modified 
 *versions of this program that are distributed or accessible shall indicate 
 *that they are based on this program.  Educational institutions are 
 *granted permission to distribute this program to their students and staff 
 *for a fee to recover distribution costs.  Permission requests for any other 
 *distribution of this program should be directed to license@u.washington.edu. 
 */ 
 
#include <windows.h> 
#include <stdlib.h> 
#include <stdio.h> 
#include "interface.h" 
#include "postscript_writer.h" 
 
#define WINBORDERH 25  /* height of menu plus caption */ 
 
char *title; 
char *label; 
char *def; 
 
typedef struct { 
    display_data parent; 
    HWND mainwin; 
    HWND dialog; 
    HMENU hmenu; 
    HWND* text; 
    HFONT font; 
    HACCEL accel; 
    int width; 
    int height; 
} win32_display_data;  
   
typedef struct { 
    graphics_context parent; 
    HDC dc; 
    HFONT font; 
    HPEN pen; 
} win32_graphics_context; 
 
win32_display_data dd; 
 
static LRESULT CALLBACK process_event( HWND hwnd, UINT msg, WPARAM wParam,  
        LPARAM lParam); 
static INT_PTR CALLBACK process_parm_event(HWND hwnd, UINT msg, WPARAM wparam, 
        LPARAM lparam); 
static void win32_get_parms(win32_display_data *dd); 
static void win32_line(win32_graphics_context *gc,int x1,int y1,int x2,int y2); 
static void win32_out_text(win32_graphics_context *gc,int x,int y, 
        char *text); 
static void win32_clear_display(win32_graphics_context *gc); 
static void event_loop(win32_display_data *dd); 
static void show_message(win32_display_data *dd,char *message); 
static void newrun_callback(void); 
static void layout_parmdialog(win32_display_data *dd); 
static void text_to_parameter(win32_display_data *dd); 
static void show_message(win32_display_data *dd,char* message); 
static void setup_callbacks(win32_display_data *dd); 
static double win32_rand(win32_display_data *dd); 
static HWND create_child_widget(char *type,char * name, int style, int x,int y, 
        int width, int height, HWND parent, int id, char *window_text, 
        int ex_style); 
static void win32_create_main_window(win32_display_data *dd,int width, 
        int height); 
static void menuitem_callback(win32_display_data *dd,int num); 
static void win32_enable_menuitem(win32_display_data *dd,menuitem* item); 
static win32_graphics_context* create_gc_from_dc(win32_display_data *dd,  
        HDC dc); 
static char* win32_get_save_file_name(win32_display_data *dd,char *title,  
        char* def); 
static char* win32_get_user_input(win32_display_data *dd, char *title, 
        char *message, char *def); 
static void win32_change_menuitem_text(win32_display_data *dd,menuitem *item); 
static char* get_menu_string(menuitem* m); 
 
static void layout_user_dialog(win32_display_data *dd) 
{ 
    int xstart = 10; 
    int xwidth = 170; 
    if (dd->text != NULL) 
        free(dd->text); 
    dd->text = malloc(sizeof(HWND)); 
    SetWindowText(dd->dialog,title); 
    create_child_widget("STATIC","label0",SS_CENTER,xstart,10,xwidth,20, 
            dd->dialog,0, label ,0); 
    dd->text[0] = create_child_widget("EDIT","edit",ES_LEFT | WS_TABSTOP, 
            xstart, 35, xwidth, 20, dd->dialog,0, def,WS_EX_CLIENTEDGE); 
    create_child_widget("BUTTON","ok_button",WS_TABSTOP | BS_DEFPUSHBUTTON,100,  
            60,75,25,dd->dialog,IDOK,"OK",0); 
    SetWindowPos(dd->dialog,HWND_TOPMOST,0,0,195 ,90 + WINBORDERH , 
            SWP_NOMOVE | SWP_NOOWNERZORDER ); 
} 
 
static void user_ok_callback(win32_display_data *dd) 
{ 
    char buf[20]; 
    SendMessage(dd->text[0],WM_GETTEXT,20,(int)buf); 
    EndDialog(dd->dialog,0); 
    def = strdup(buf); 
} 
 
static INT_PTR CALLBACK process_user_event(HWND hwnd, UINT msg, WPARAM wparam, 
        LPARAM lparam) { 
    dd.dialog=hwnd; 
    switch (msg) { 
        case WM_INITDIALOG: 
            layout_user_dialog(&dd); 
            return FALSE; /* This is where to layout the dialog */ 
        case WM_COMMAND: 
            if (wparam == IDOK)  { 
                user_ok_callback(&dd); 
            } 
        default:  
            return FALSE; 
    } 
} 
 
static char* win32_get_user_input(win32_display_data *dd, char *w_title, 
        char *message, char *w_def) 
{ 
    title = w_title; 
    label = message; 
    def = w_def; 
    DialogBox(NULL,"InputDlg",dd->mainwin,process_user_event); 
    return def; 
} 
 
static void show_message(win32_display_data *dd,char* message) 
{ 
    MessageBox(dd->mainwin,message,"",MB_OK|MB_TASKMODAL); 
} 
 
 
static void parm_ok_callback(win32_display_data *dd)  
{        
    text_to_parameter(dd);	 
    EndDialog(dd->dialog,0); 
} 
 
static void text_to_parameter(win32_display_data *dd) 
{ 
    int i; 
    char buf[20]; 
    int nullskipper=0; 
 
    for (i = 0; i < NUM_PARMS; i++) { 
        if ( dd->parent.parms[i].label == NULL) { 
            nullskipper++; 
            continue; 
        } 
        SendMessage(dd->text[i-nullskipper],WM_GETTEXT,20,(int)buf); 
        switch(dd->parent.parms[i].type) { 
        case P_LONG: 
          dd->parent.parms[i].data=atoi(buf); 
          break; 
        case P_DOUBLE: 
          dd->parent.parms[i].data=atof(buf); 
          break; 
        case P_BOOL: 
        case P_STRING: 
        default:
          break;
        } 
    } 
} 
 
static HWND create_child_widget(char *type,char * name, int style, int x,int y, 
        int width, int height, HWND parent, int id, char *window_text, 
        int ex_style) 
{ 
    HWND ret; 
    ret = CreateWindowEx(ex_style,type,name,WS_CHILD | style,x,y,width,height, 
            parent,(void*)id,NULL, NULL); 
    SendMessage(ret,WM_SETFONT,(int)dd.font,TRUE); 
    SetWindowText(ret,window_text); 
    ShowWindow(ret,SW_SHOW); 
    return ret; 
} 
 
static void layout_parmdialog(win32_display_data *dd)  
{ 
    HWND label,button; 
    HFONT f; 
    int i; 
    int nullskipper=0; 
    char buf[20]; 
    char buf2[10]; 
    
    SetWindowText(dd->dialog,"PopG Settings"); 
    if (dd->text != NULL) 
        free(dd->text); 
    dd->text = malloc(NUM_PARMS * sizeof (HWND)); 
    create_child_widget("STATIC","label0",SS_CENTER,0,20,400,20, 
            dd->dialog,0, "PopG Settings",0); 
     
    for (i=0;i<NUM_PARMS;i++) { 
        if (dd->parent.parms[i].label == NULL) { 
            nullskipper++; 
            continue; 
        } 
        sprintf(buf,"label%d",i+1-nullskipper); 
        create_child_widget("STATIC",buf,SS_CENTER,0,(i+2-nullskipper)*25+2, 
                250,30,dd->dialog,i+2000-nullskipper, 
                dd->parent.parms[i].label,0); 
        sprintf(buf,"text%d",i+1-nullskipper); 
        sprintf(buf2,"%g",dd->parent.parms[i].data); 
        dd->text[i-nullskipper] = create_child_widget("EDIT",buf,ES_LEFT |  
                WS_TABSTOP,250,(i+2-nullskipper)*25, 150,20,dd->dialog,0, 
                buf2,WS_EX_CLIENTEDGE); 
    } 
    create_child_widget("BUTTON","ok_button",WS_TABSTOP | BS_DEFPUSHBUTTON,325,  
            (i+2-nullskipper)*25+5,75,25,dd->dialog,IDOK,"OK",0); 
    SetWindowPos(dd->dialog,HWND_TOPMOST,0,0, 420 , 
            (i + 3 - nullskipper)*25 + 40 , SWP_NOMOVE | SWP_NOOWNERZORDER ); 
} 
 
 
static INT_PTR CALLBACK process_parm_event(HWND hwnd, UINT msg, WPARAM wparam, 
        LPARAM lparam) { 
    dd.dialog=hwnd; 
    switch (msg) { 
        case WM_INITDIALOG: 
            layout_parmdialog(&dd); 
            return FALSE; /* This is where to layout the dialog */ 
        case WM_COMMAND: 
            if (wparam == IDOK)  { 
                parm_ok_callback(&dd); 
            } 
        default:  
            return FALSE; 
    } 
} 
 
static void win32_get_parms(win32_display_data *dd)  
{  
    DialogBox(NULL,"ParmDlg",dd->mainwin,process_parm_event); 
} 
 
static void win32_flush(win32_display_data *dd)  
{ /* not needed on win32 Here it is just in case we have problems later */ 
    /* GdiFlush(); */ 
} 
 
/* We aren't using cygwin rand(), but we are using MS rand, when compiling 
 * under cygwin RAND_MAX is defined diffrently, here is a fix for compiling 
 * under cygwin. */ 
#ifdef RAND_MAX 
#undef RAND_MAX 
#endif /* RAND_MAX */ 
 
#define RAND_MAX 0x7fff 
static double win32_rand(win32_display_data *dd)  
{ 
    return (double)rand()/(double)RAND_MAX; 
} 
 

static int win32_string_width(win32_graphics_context *gc,char *string) 
{
    ABCFLOAT char_width;
    float string_width = 0;
    int i,length;
    
    length = strlen(string);
    for ( i = 0 ; i < length ; i++ ) {
        GetCharABCWidthsFloat(gc->dc,string[i],string[i],&char_width);
        string_width += char_width.abcfA + char_width.abcfB + char_width.abcfC;
    }
    return string_width;
}


static void win32_line(win32_graphics_context *gc,int x1,int y1, int x2,int y2) 
{  
    MoveToEx(gc->dc,x1,y1, (LPPOINT)NULL); 
    LineTo(gc->dc,x2,y2); 
} /* line */ 
 
void win32_out_text(win32_graphics_context *gc,int x,int y,char *text) 
{  
    TextOut(gc->dc,x,y - gc->parent.half_text_height * 2,text,strlen(text)); 
 
} /* out_text */ 
 
 
void win32_clear_display(win32_graphics_context *gc) 
{ 
    PatBlt(gc->dc,0,0,gc->parent.width,gc->parent.height,WHITENESS);  
} 
 
static void event_loop(win32_display_data *dd)  
{ 
    MSG msg; 
    while ( GetMessage( &msg, NULL, 0, 0)) { 
        if (TranslateAccelerator(dd->mainwin,dd->accel,&msg) == 0) { 
		TranslateMessage( &msg ); 
		DispatchMessage( &msg ); 
	} 
    } 
} 
 
LRESULT CALLBACK process_event( HWND hwnd, UINT msg, WPARAM wParam,  
        LPARAM lParam ) 
{ 
    PAINTSTRUCT ps; 
    LOGBRUSH lb; 
    HBRUSH bgbrush;  
    HDC dc; 
    win32_graphics_context *gc; 
 
    switch(msg) { 
        case WM_ACTIVATE: 
            if (wParam != WA_INACTIVE) 
                BringWindowToTop(hwnd); 
            break; 
        case WM_DESTROY: 
            exit(0); 
            break; 
        case WM_PAINT: 
            dc = BeginPaint(hwnd,&ps); 
            gc = create_gc_from_dc(&dd,dc); 
            gc->parent.width = dd.width; 
            gc->parent.height = dd.height; 
            draw_graph((graphics_context*)gc,dd.parent.parms,dd.parent.run); 
            EndPaint(hwnd,&ps); 
            DeleteObject(gc->font); 
            DeleteObject(gc->pen); 
            free(gc); 
            break; 
        case WM_SIZE: 
            dd.width = LOWORD(lParam); 
            dd.height = HIWORD(lParam); 
            if (dd.parent.gc) { 
                dd.parent.gc->height = dd.height; 
                dd.parent.gc->width = dd.width; 
            } 
            UpdateWindow(hwnd); 
            break; 
        case WM_COMMAND: 
            menuitem_callback(&dd,wParam); 
            break; 
        default: 
            return( DefWindowProc( hwnd, msg, wParam, lParam )); 
    } 
    return 0; 
} 
 
static void win32_print(win32_display_data *dd) 
{ 
    PRINTDLG pd; 
    HWND hd; 
    DOCINFO di; 
    win32_graphics_context *gc; 
    int i; 
     
    ZeroMemory(&pd,sizeof(PRINTDLG)); 
    pd.lStructSize = sizeof(PRINTDLG); 
    pd.hwndOwner = dd->mainwin; 
    pd.hDevMode = NULL; 
    pd.hDevNames = NULL; 
    pd.Flags = PD_USEDEVMODECOPIESANDCOLLATE | PD_RETURNDC | PD_NOPAGENUMS; 
    pd.nCopies = 1; 
    pd.nFromPage = 0xffff; 
    pd.nToPage = 0xffff; 
    pd.nMinPage = 1; 
    pd.nMaxPage = 0xffff; 
 
    if (PrintDlg(&pd) == TRUE) { 
        gc = create_gc_from_dc(dd,pd.hDC);  
 
        di.cbSize=sizeof(di); 
        di.lpszDocName = "PopG"; 
        di.lpszOutput = NULL; 
        di.lpszDatatype = NULL; 
        di.fwType = 0; 
        i = StartDoc(gc->dc,&di); 
        i = StartPage(gc->dc); 
        draw_graph((graphics_context*)gc,dd->parent.parms,dd->parent.run); 
        EndPage(gc->dc); 
        EndDoc(gc->dc); 
        DeleteDC(gc->dc); 
        DeleteObject(gc->font); 
        DeleteObject(gc->pen); 
        free(gc); 
    } 
} 
 
static void setup_gc_callbacks(win32_graphics_context *gc)  
{ 
    gc->parent.line = (line_t)win32_line; 
    gc->parent.out_text = (out_text_t)win32_out_text; 
    gc->parent.clear_display = (clear_display_t)win32_clear_display; 
    gc->parent.flush = (flush_t)win32_flush; 
    gc->parent.string_width = (string_width_t)win32_string_width;
} 
 
static void setup_callbacks(win32_display_data *dd)  
{ 
    dd->parent.rand = (rand_t)win32_rand; 
    dd->parent.create_main_window =  
             (create_main_window_t)win32_create_main_window; 
    dd->parent.start = (start_t)event_loop; 
    dd->parent.get_parms = (get_parms_t)win32_get_parms; 
    dd->parent.enable_menuitem = (enable_menuitem_t)win32_enable_menuitem; 
    dd->parent.change_menuitem_text = (change_menuitem_text_t) 
        win32_change_menuitem_text; 
    dd->parent.get_save_file_name =  
        (get_save_file_name_t)win32_get_save_file_name; 
    dd->parent.show_message = (show_message_t)show_message;
    dd->parent.print = (print_t)win32_print; 
    dd->parent.get_user_input = (get_user_input_t)win32_get_user_input; 
} 
 
static win32_graphics_context* create_gc_from_dc(win32_display_data *dd, HDC dc) 
{ 
    LOGFONT lf; 
    int thick; 
    win32_graphics_context* gc; 
 
    gc = malloc(sizeof(win32_graphics_context)); 
    gc->dc = dc; 
    gc->parent.width = GetDeviceCaps(gc->dc,HORZRES); 
    gc->parent.height = GetDeviceCaps(gc->dc,VERTRES); 
     
    ZeroMemory(&lf,sizeof(lf)); 
    lf.lfHeight = 14 * GetDeviceCaps(gc->dc, LOGPIXELSY) / 72; 
    lf.lfCharSet = ANSI_CHARSET; 
    lf.lfOutPrecision = OUT_DEFAULT_PRECIS; 
    lf.lfClipPrecision = CLIP_DEFAULT_PRECIS; 
    lf.lfQuality = DEFAULT_QUALITY; 
    lf.lfPitchAndFamily = DEFAULT_PITCH | FF_SWISS; 
    gc->font = CreateFontIndirect(&lf); 
    SelectObject(gc->dc,gc->font); 
    gc->parent.half_text_height = (lf.lfHeight + 1) / 2; 
    
 
    thick = 1 * GetDeviceCaps(gc->dc, LOGPIXELSY) / 72; 
    gc->pen = CreatePen(PS_SOLID,thick,0); 
    SelectObject(gc->dc,gc->pen); 
 
    setup_gc_callbacks(gc); 
    return gc; 
} 
 
static win32_graphics_context* create_gc_from_hwnd(win32_display_data *dd,  
        HWND hwnd) 
{ 
    HDC dc; 
 
    dc = GetDC(hwnd); 
    return create_gc_from_dc(dd,dc); 
} 
 
static void win32_change_menuitem_text(win32_display_data *dd,menuitem *item) 
{ 
    char *tmp; 
     
    tmp = get_menu_string(item); 
    ModifyMenu(dd->hmenu,(UINT)item->app_data,MF_BYCOMMAND, 
            (UINT)item->app_data,tmp); 
    free(tmp); 
} 
 
static void win32_enable_menuitem(win32_display_data *dd,menuitem* item) 
{ 
    EnableMenuItem(dd->hmenu,(UINT)item->app_data,MF_ENABLED | MF_BYCOMMAND); 
} 
 
 
static void menuitem_callback(win32_display_data *dd,int num)  
{ 
    int i,j; 
    menubar* app_menu = dd->parent.app_menu; 
    menuitem *item; 
     
    num = LOWORD(num); 
    for ( i = 0 ; i < app_menu->num_menus ; i++) { 
        for ( j = 0 ; j < app_menu->menus[i].num_items ; j++ ) { 
            item = app_menu->menus[i].items + j; 
            if (item->app_data == (void*)num) 
                if ( item->callback != NULL ) 
                    item->callback((display_data*)dd); 
        } 
    } 
} 
 
static char* win32_get_save_file_name(win32_display_data *dd,char *title,  
        char* def) 
{ 
    /* def the default gets ignored until we can construct a full path 
     * which GetSaveFileName expects 
     * on Unix it would be along the lines of strcat(getpwd(),def); */ 
    OPENFILENAME of; 
	char temp[513];
	strcpy(temp, def);
    ZeroMemory(&of,sizeof(OPENFILENAME)); 
     
    of.lStructSize = sizeof(OPENFILENAME); 
    of.hwndOwner = dd->mainwin; 
    of.lpstrFilter = "Postscript Files\0*.ps\0\0"; 
	of.lpstrFile = temp;
	of.nMaxFile = 512;
	of.Flags = OFN_OVERWRITEPROMPT;
	GetSaveFileName(&of);
    if (of.lpstrFile != NULL) 
        return strdup(of.lpstrFile); 
    else  
        return NULL; 
} 
 
static char* get_menu_string(menuitem* m) 
{ 
    char *ret; 
    char buffer[10]; 
     
    if (m->accelerator == 0) 
       return strdup(m->label);  
 
    ret = malloc(strlen(m->label) + 20); 
    strcpy(ret,m->label); 
    sprintf(buffer,"\tCtrl+%c",m->accelerator); 
    strcat(ret,buffer); 
    return ret; 
} 
 
 
static void win32_create_main_window(win32_display_data *dd,int width, 
        int height)  
{   
    HMENU hmenu,hmenu2; 
    LPACCEL tables; 
    int i,j,sum; 
    menubar* app_menu = dd->parent.app_menu; 
    menuitem* item; 
    unsigned int counter = 1000,enabled; 
    char* tmp; 
 
    dd->width = width; 
    dd->height = height; 
    dd->mainwin =  
        CreateWindow( "GenericAppClass", "PopG" , WS_OVERLAPPEDWINDOW,  
                0, 0, width, height + WINBORDERH, NULL, NULL, NULL, NULL); 
   
    hmenu = CreateMenu();  
    dd->hmenu = hmenu; 
 
    sum = 0;  
    for ( i = 0 ; i < app_menu->num_menus ; i++)  
        for ( j = 0 ; j < app_menu->menus[i].num_items ; j++ )  
            sum++; 
    tables = malloc(sum * sizeof(ACCEL)); 
    sum = 0; 
     
    for ( i = 0 ; i < app_menu->num_menus ; i++) { 
        hmenu2 = CreatePopupMenu(); 
        AppendMenu(hmenu,MF_STRING | MF_POPUP,(UINT)hmenu2, 
                       app_menu->menus[i].label); 
        for ( j = 0 ; j < app_menu->menus[i].num_items ; j++ ) { 
            item = app_menu->menus[i].items + j; 
            tmp = get_menu_string(item); 
            AppendMenu(hmenu2,MF_STRING,counter,tmp); 
            free(tmp); 
            if ( item->enabled) 
                enabled = MF_ENABLED | MF_BYCOMMAND; 
            else 
                enabled = MF_GRAYED | MF_BYCOMMAND; 
            EnableMenuItem(hmenu,counter,enabled); 
            item->app_data = (void*) counter; 
            tables[sum].fVirt = FCONTROL | FVIRTKEY; 
            tables[sum].key = toupper(item->accelerator); 
            tables[sum].cmd = counter; 
            counter++; 
            sum++; 
        } 
    } 
     
    dd->accel = CreateAcceleratorTable(tables,sum); 
     
    SetMenu(dd->mainwin,hmenu);  
    dd->parent.gc = (graphics_context*)create_gc_from_hwnd(dd,dd->mainwin);  
    ShowWindow( dd->mainwin, SW_SHOWNORMAL ); 
} 
 
display_data* init_ui(int argc,char **argv) 
{ 
    WNDCLASS wc; 
 
    srand(time(NULL));  
    setup_callbacks(&dd); 
 
    wc.lpszClassName = "GenericAppClass"; 
    wc.lpfnWndProc = process_event; 
    wc.style = CS_OWNDC | CS_VREDRAW | CS_HREDRAW; 
    wc.hInstance = NULL; 
    wc.hIcon = LoadIcon( NULL, IDI_APPLICATION ); 
    wc.hCursor = LoadCursor( NULL, IDC_ARROW ); 
    wc.hbrBackground = (HBRUSH)( COLOR_WINDOW+1 ); 
    wc.lpszMenuName = NULL; 
    wc.cbClsExtra = 0; 
    wc.cbWndExtra = 0; 
 
    RegisterClass( &wc ); 
     
    dd.font = GetStockObject(DEFAULT_GUI_FONT); 
    dd.text = NULL; 
    dd.accel = NULL; 
    
    return (display_data*)&dd; 
} 
 
