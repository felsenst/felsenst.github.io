/*
 *Copyright 1993-2003.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Educational institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */

#include "interface.h"
#include "popg.h"
#include "postscript_writer.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/* TODO landscape would be real nice */

#define TEXT_HEIGHT 28 

static void p_line(p_graphics_context *gc,int x1,int y1,int y2,int y3);
static void p_out_text(p_graphics_context *gc, int x, int y, char *text);
static void p_clear_display(void);
static void p_flush(void);
static int p_string_width(p_graphics_context *gc,char *string);

void setup_pgc(p_graphics_context *gc)
{
    gc->parent.width = 1300;
    gc->parent.height = 800; /* This is how I set it up */
    gc->parent.line = (line_t)p_line;
    gc->parent.out_text = (out_text_t)p_out_text;
    gc->parent.clear_display = (clear_display_t)p_clear_display;
    gc->parent.flush = (flush_t)p_flush;
    gc->parent.string_width = (string_width_t) p_string_width;
    gc->parent.half_text_height = TEXT_HEIGHT / 2.6; 
    /* FIXME I am just guessing here, from trial and error, the proper way to 
     * find this number is to look at some kind of postscript referance */
}

static int p_string_width(p_graphics_context *gc,char *string) 
{
   return strlen(string)*14; /*again I'm gussing here the proper way would
                                be to have some kind of table and look up 
                                each letter */
}

void write_postscript_file(char *file_name,parameter *parms, run_data* run) 
{
    p_graphics_context gc;
    setup_pgc(&gc);
    
    gc.file=fopen(file_name,"w");
    if (gc.file == NULL) return; /* TODO devise a way of handling this */
    write_prolog(&gc,file_name);
    draw_graph((graphics_context*)&gc,parms,run);
    write_footer(&gc);
    fclose(gc.file);
}

static void p_line(p_graphics_context *gc,int x1, int y1, int x2, int y2)
{
    fprintf(gc->file, "%d %d %d %d L\n", x1,-y1,x2,-y2);
}

static void p_out_text(p_graphics_context *gc, int x, int y, char *text)
{
    fprintf(gc->file, "(%s) %d %d  T\n",text,x,-y);
}

static void p_clear_display(void) {} /* doesn't mean anything */
static void p_flush(void) {} /* ibid */

void write_prolog(p_graphics_context *gc, char *title)
{
  fprintf(gc->file, "%%!PS-Adobe-2.0\n");
  fprintf(gc->file, "%%%%Creator: PopG\n");
  fprintf(gc->file, "%%%%Title %s\n", title);
  fprintf(gc->file, "%%%%Orientation: Landscape\n");
  fprintf(gc->file, "%%%%EndComments\n");
  fprintf(gc->file, "%%%%BeginProlog\n");
  fprintf(gc->file, "\n");

  fprintf(gc->file, "/T {\n");
  fprintf(gc->file, "gsave\n");
  fprintf(gc->file, "\tmoveto show grestore\n");
  fprintf(gc->file, "\t} bind def\n");
  fprintf(gc->file, "\n");

  fprintf(gc->file, "/L {\n");
  fprintf(gc->file, "\tmoveto lineto stroke\n");
  fprintf(gc->file, "\t} bind def\n");
  fprintf(gc->file, "\n");

  fprintf(gc->file, "%%%%EndProlog\n");

  fprintf(gc->file, "90 rotate\n");
  fprintf(gc->file, "50 -100 translate\n");
  fprintf(gc->file, ".55 .55 scale\n");
  fprintf(gc->file, "/Helvetica findfont %d scalefont setfont\n",
          TEXT_HEIGHT);
}

void write_footer(p_graphics_context *gc) 
{
    fprintf(gc->file,"showpage\n");
    fprintf(gc->file,"%%%%EOF\n");
}

