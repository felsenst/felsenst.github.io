/*
 *Copyright 1993-2003.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Education institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "interface.h"
#include "postscript_writer.h"

#define FONT "-*-helvetica-medium-r-normal-*-14-*"
#define NUMLABELS 11
#define NUMTEXT 10

typedef struct {
  display_data parent;
  GtkWidget* toplevel;
  GtkWidget* parm_dialog;
  GtkWidget *drawing_area;
  GtkWidget **text;
} gtk_display_data; 

typedef struct {
  graphics_context parent; 
  GtkWidget *d;
  GdkPixmap *pxm;
  GdkGC* blackgc;
  GdkGC* whitegc;
  GdkFont *font;
} gtk_graphics_context;

static void redraw(GtkWidget* drawing_area, GdkEventExpose *event, 
    gtk_graphics_context* gc);
static void gtk_get_parms(gtk_display_data *dd);
static void parameter_to_text(parameter* parms,GtkWidget **text);
static void text_to_parameter(parameter* parms,GtkWidget **text);
static void setup_callbacks(gtk_display_data *dd);
static void gtk_line(gtk_graphics_context *gc,int x1,int y1,int x2,int y2);
static void gtk_out_text(gtk_graphics_context *gc,int x,int y,char *text);
static void gtk_clear_display(gtk_graphics_context *gc);
static void event_loop(gtk_display_data *dd);
static void gtk_show_message(gtk_display_data *dd,char *message);
static void layout_toplevel(gtk_display_data *dd, menubar *app_menu,int width,
        int height);
static char* gtk_get_user_input(gtk_display_data *dd, char *title, 
    char *message, char *def);
static void gtk_create_main_window(gtk_display_data *dd,int width, int height);
static void gtk_print(gtk_display_data *dd);
static void resize(GtkWidget* drawing_area, GtkAllocation *req,
    gtk_display_data *dd);
static char* gtk_get_save_file_name(gtk_display_data *dd,char *title, 
    char* def);
static void gtk_change_menuitem_text(gtk_display_data *dd,menuitem *m);
void dialog_delete(GtkWidget* w);
static void print_postscript_file(parameter *parms, run_data* run);
static void store_filename(GtkWidget *widget, int* ok);

static void gtk_change_menuitem_text(gtk_display_data *dd,menuitem *m)
{
  gtk_label_set_text(GTK_LABEL(gtk_bin_get_child(GTK_BIN(m->app_data))),
      m->label);
}

static void store_filename(GtkWidget *widget, int* ok)
{
  *ok = TRUE;
  gtk_main_quit();
}

static char* gtk_get_save_file_name(gtk_display_data *dd,char *title, char* def)
{
  int ok = FALSE;
  char *fname;
  GtkWidget *file_selector;

  file_selector = gtk_file_selection_new("Please select were to save file");
  g_signal_connect(GTK_FILE_SELECTION(file_selector)->ok_button,
      "clicked",G_CALLBACK(store_filename),&ok);
  g_signal_connect_swapped(GTK_FILE_SELECTION(file_selector)->ok_button,
      "clicked",G_CALLBACK(gtk_widget_hide),file_selector);
  g_signal_connect_swapped(GTK_FILE_SELECTION(file_selector)->cancel_button,
      "clicked",G_CALLBACK(gtk_widget_destroy),file_selector);
  gtk_widget_show(file_selector);
  gtk_main();
  if ( ok ) {
    fname = g_strdup( gtk_file_selection_get_filename(
          GTK_FILE_SELECTION(file_selector)));
    gtk_widget_destroy(file_selector);
    return fname;
  } else 
    return NULL;
}

static void gtk_enable_menuitem(gtk_display_data *dd,menuitem* m) 
{
    gtk_widget_set_sensitive(GTK_WIDGET(m->app_data),TRUE);
}

static char* gtk_get_user_input(gtk_display_data *dd, char *title, 
    char *message, char* def)
{ 
    GtkWidget* dialog;
    GtkWidget* label;
    GtkWidget* entry;
    char *ret;
 
    dialog = gtk_dialog_new_with_buttons(title,GTK_WINDOW(dd->toplevel),
        GTK_DIALOG_MODAL,GTK_STOCK_OK,GTK_RESPONSE_OK,NULL);

    label = gtk_label_new(message);
   
    gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), label, FALSE, FALSE,
        0);

    entry = gtk_entry_new();
    gtk_entry_set_text(GTK_ENTRY(entry),def);
    gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dialog)->vbox), entry, FALSE, FALSE,
        0);
    gtk_widget_show_all(dialog); 
    gtk_dialog_run(GTK_DIALOG(dialog));
    ret = g_strdup(gtk_entry_get_text(GTK_ENTRY(entry)));
    gtk_widget_destroy(dialog);
    return ret;
}


static void parameter_to_text(parameter* parms,GtkWidget **text) 
{
    int i,nullcount=0;
    char buf[100];
    
    for ( i = 0 ; i < NUM_PARMS ; i++ ) { 
        switch ( parms[i].type) {
            case P_LONG:
                sprintf(buf,"%ld",(long)(parms[i].data));
                break;
            case P_DOUBLE:
                sprintf(buf,"%f",parms[i].data);
                break;
            case P_BOOL: /* not handled yet*/
            case P_STRING:
                buf[0] = 0;
                break;
        }
        if ( parms[i].label == NULL) {
            nullcount++;
            continue;
        }
        gtk_entry_set_text(GTK_ENTRY(text[i-nullcount]),buf);
    }
}

static void text_to_parameter(parameter* parms,GtkWidget **text) 
{
    int i,nullcount=0;
    const char* dp;
    
    for ( i = 0 ; i < NUM_PARMS ; i++ ) { 
        if ( parms[i].label == NULL) {
            nullcount++;
            continue;
        }
        dp = gtk_entry_get_text(GTK_ENTRY(text[i-nullcount]));
        switch ( parms[i].type) {
            case P_LONG:
                parms[i].data = atoi(dp);
                break;
            case P_DOUBLE:
                parms[i].data = atof(dp);
                break;
            case P_BOOL: /* not handled yet*/
            case P_STRING:
                break;
        }
    }
}

static void gtk_get_parms(gtk_display_data *dd) 
{

  GtkWidget* label[NUMLABELS];
  GtkWidget* table;
  int nullcount=0;
  int j = 0;

  dd->text = malloc(NUMTEXT * sizeof(GtkWidget*));

  /* Create The Dialog */
  dd->parm_dialog = gtk_dialog_new_with_buttons("Parameters",
      GTK_WINDOW(dd->toplevel), GTK_DIALOG_MODAL, GTK_STOCK_OK, 
      GTK_RESPONSE_OK,NULL);
  table = gtk_table_new(1,1,FALSE);
  gtk_box_pack_start(GTK_BOX(GTK_DIALOG(dd->parm_dialog)->vbox),table,TRUE,
      TRUE,0);
  
  /* Create The Labels */
  
  for (j = 0; j <= NUM_PARMS ; j++) {
    if (dd->parent.parms[j].label == NULL) {
      nullcount++;
      continue;
    }
    label[j-nullcount] = gtk_label_new(dd->parent.parms[j-nullcount].label);
    gtk_table_attach(GTK_TABLE(table),label[j-nullcount],0,1,j-nullcount,
        j-nullcount+1,GTK_FILL, GTK_FILL,5,5);
  }

  /* Create the text boxes */
  for (j = 0 ; j < NUMTEXT; j++) {
    dd->text[j] = gtk_entry_new();
    gtk_table_attach(GTK_TABLE(table),dd->text[j],1,2,j+1,j+2,GTK_FILL,
        GTK_FILL,5,5);
  }

  parameter_to_text(dd->parent.parms,dd->text);
  /* show it */
  gtk_widget_show_all(dd->parm_dialog); 
  gtk_dialog_run(GTK_DIALOG(dd->parm_dialog));

  text_to_parameter(dd->parent.parms,dd->text);
  gtk_widget_destroy(dd->parm_dialog);
  dd->parm_dialog = NULL;
}

static void gtk_flush(gtk_graphics_context *gc) {
    redraw(NULL,NULL,gc);
}

static double gtk_rand(gtk_display_data *dd) {
    return (((double) (random())) / (double) RAND_MAX);	
}

static void redraw(GtkWidget *w,GdkEventExpose *event,gtk_graphics_context *gc) 
{
  gdk_draw_drawable(gc->d->window,gc->blackgc,gc->pxm,0,0,0,0,-1,-1);
}

static void gtk_line(gtk_graphics_context *gc,int x1,int y1,int x2,int y2)
{ 
  gdk_draw_line(gc->pxm,gc->blackgc, x1,y1,x2,y2);
} /* line */

void gtk_out_text(gtk_graphics_context *gc,int x,int y,char *text)
{ 
  gdk_draw_string(gc->pxm,gc->font,gc->blackgc,x,y,text);
} /* out_text */

void gtk_clear_display(gtk_graphics_context *gc)
{
  gdk_draw_rectangle(gc->pxm,gc->whitegc,TRUE,0,0,1000,1000);
  redraw(NULL,NULL,gc); 
}

static int gtk_string_width(gtk_graphics_context* gc,char* string)
{
  return gdk_string_width(gc->font,string);
}

static gtk_graphics_context* create_gc(gtk_display_data *dd, GtkWidget* d) 
{
  gtk_graphics_context *gc;
  GdkGCValues values; 
  GdkColor white = {0,65535,65535,65535}; 

  gc = malloc(sizeof(gtk_graphics_context));
  gc->parent.width=800;
  gc->parent.height=800;
  gc->d = d;
  gc->pxm = gdk_pixmap_new(d->window,1000,1000,-1);
  gc->blackgc = gdk_gc_new(d->window); 
  gdk_gc_get_values(gc->d->style->fg_gc[GTK_WIDGET_STATE(gc->d)],&values);
  gc->font = gdk_font_load("fixed");
  gdk_gc_set_font(gc->blackgc,gc->font);
  gc->parent.half_text_height = gdk_char_height(gc->font,'A')/2; 

  gc->whitegc = gdk_gc_new(d->window);
  gdk_gc_set_rgb_fg_color(gc->whitegc,&white);

  gc->parent.line = (line_t)gtk_line;
  gc->parent.out_text = (out_text_t)gtk_out_text;
  gc->parent.clear_display = (clear_display_t)gtk_clear_display;
  gc->parent.flush = (flush_t)gtk_flush;
  gc->parent.string_width = (string_width_t)gtk_string_width;

  return gc;
}

static void setup_callbacks(gtk_display_data *dd) 
{
    dd->parent.rand = (rand_t)gtk_rand;
    dd->parent.create_main_window = 
      (create_main_window_t)gtk_create_main_window;
    dd->parent.start = (start_t)event_loop;
    dd->parent.get_parms = (get_parms_t)gtk_get_parms;
    dd->parent.enable_menuitem = (enable_menuitem_t)gtk_enable_menuitem;
    dd->parent.change_menuitem_text = (change_menuitem_text_t)
        gtk_change_menuitem_text; 
    dd->parent.get_user_input = (get_user_input_t)gtk_get_user_input;
    dd->parent.print = (print_t)gtk_print;
    dd->parent.show_message = (show_message_t)gtk_show_message;
    dd->parent.get_save_file_name = (get_save_file_name_t)gtk_get_save_file_name;
}

static void event_loop(gtk_display_data *dd) 
{
  gtk_main();
}

static void gtk_show_message(gtk_display_data *dd,char * message )
{
  GtkWidget *dlg;
  dlg = gtk_message_dialog_new(GTK_WINDOW(dd->toplevel),GTK_DIALOG_MODAL,
      GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"%s",message);
  gtk_dialog_run(GTK_DIALOG(dlg));
  gtk_widget_destroy(dlg);
}

static void menuitem_callback(GtkWidget *w,gtk_display_data *dd) 
{
    int i,j;
    menubar* app_menu = dd->parent.app_menu;
    menuitem *item;
    for ( i = 0 ; i < app_menu->num_menus ; i++) {
        for ( j = 0 ; j < app_menu->menus[i].num_items ; j++ ) {
            item = app_menu->menus[i].items + j;
            if (item->app_data == w)
                if ( item->callback != NULL )
                    item->callback((display_data*)dd);
        }
    }
}

static void layout_toplevel(gtk_display_data *dd, menubar *app_menu,int width,
        int height) 
{
  GtkWidget* vbox;
  GtkWidget* menubar1;
  GtkWidget* menuitem;
  GtkWidget* menu;
  GtkWidget* menubutton;
  int i,j;

  vbox = gtk_vbox_new(FALSE,0);
  gtk_container_add(GTK_CONTAINER(dd->toplevel),vbox);
 
  menubar1 = gtk_menu_bar_new();
  gtk_box_pack_start(GTK_BOX(vbox),menubar1,FALSE,FALSE,0);

  /* setup menus */
 for ( i = 0 ; i < app_menu->num_menus ; i++) {
   menu = gtk_menu_new();
   menubutton = gtk_menu_item_new_with_label(app_menu->menus[i].label);
   gtk_menu_shell_append(GTK_MENU_SHELL(menubar1),menubutton);           
      for ( j = 0 ; j < app_menu->menus[i].num_items ; j++ ) {
        menuitem = gtk_menu_item_new_with_label(
            app_menu->menus[i].items[j].label);
        gtk_menu_shell_append(GTK_MENU_SHELL(menu),menuitem);
        app_menu->menus[i].items[j].app_data = menuitem;
        gtk_widget_set_sensitive(menuitem,app_menu->menus[i].items[j].enabled);
        g_signal_connect(G_OBJECT(menuitem),"activate",
              G_CALLBACK(menuitem_callback),dd);
      }
      gtk_menu_item_set_submenu(GTK_MENU_ITEM(menubutton),menu);
  }
  dd->drawing_area = gtk_drawing_area_new();
  gtk_window_set_default_size(GTK_WINDOW(dd->toplevel),width,height);
  gtk_box_pack_start(GTK_BOX(vbox),dd->drawing_area,TRUE,TRUE,0);
  g_signal_connect(G_OBJECT(dd->drawing_area),"size-allocate",G_CALLBACK(resize)
      ,dd);
  g_signal_connect(G_OBJECT(dd->toplevel),"delete-event",G_CALLBACK(gtk_main_quit),0);
  gtk_widget_show_all(dd->toplevel);
}

static void resize(GtkWidget* drawing_area, GtkAllocation *alloc,
    gtk_display_data *dd) 
{
  if ( dd->parent.gc == NULL) return;
  dd->parent.gc->width = alloc->width; 
  dd->parent.gc->height = alloc->height; 
  draw_graph(dd->parent.gc,dd->parent.parms,dd->parent.run);
}

static void gtk_print(gtk_display_data *dd)
{
    print_postscript_file(dd->parent.parms,dd->parent.run);
}

static void gtk_create_main_window(gtk_display_data *dd,int width,int height)
{
  dd->toplevel = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(dd->toplevel),"popg");
  layout_toplevel(dd,dd->parent.app_menu,width,height); 
  dd->parent.gc = (graphics_context*)create_gc(dd,dd->drawing_area);
  resize(dd->drawing_area,&(dd->drawing_area->allocation),dd);
  g_signal_connect(G_OBJECT(dd->drawing_area),"expose_event",
      G_CALLBACK(redraw),dd->parent.gc);
  draw_graph(dd->parent.gc,dd->parent.parms,dd->parent.run);
  redraw(NULL,NULL,(gtk_graphics_context*)dd->parent.gc);
}

display_data* init_ui(int argc,char **argv)
{ 
    gtk_display_data *dd;
    srandom(time(NULL));
    
    dd = calloc(1,sizeof(gtk_display_data));
    setup_callbacks(dd);
    gtk_init(&argc,&argv);
    
    return (display_data*)dd;
}

static void print_postscript_file(parameter *parms, run_data* run) 
{
    p_graphics_context gc;
    setup_pgc(&gc); 

    gc.file=popen("lpr","w");
    write_prolog(&gc,"PopG");
    draw_graph((graphics_context*)&gc,parms,run);
    write_footer(&gc);
    fclose(gc.file);
}
