/*
 *Copyright 1993-2003.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Educational institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */

#include "popg.h"

#define BOOL int 

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif /* TRUE */

#ifdef __MWERKS__
#ifndef WIN32
#define MAC
#endif
#endif

typedef struct _display_data display_data;
typedef struct _graphics_context graphics_context;

/* Start of menu stuff */

/* For now only support singly nested menus, This can be easily changed, but
 * I'm not sure it's needed nor wanted.
 * i.e. File->Quit not Text->properties->italic */
typedef void (*menu_callback)(display_data *dd);   

typedef struct {
    char *label;  /* what the user sees, e.g. Print */
    BOOL enabled; /* weather this menu item is enabled or not */        
    menu_callback callback; /* when selected call this function */
    char accelerator; /* e.g. Ctrl+P for Print */
    void *app_data; /* system specific data, do not modify */
}menuitem;

typedef struct {
    char *label;
    int num_items;
    menuitem *items;
}menu;

typedef struct {
    int num_menus;
    menu *menus;
} menubar;
/* End of menu stuff */

/* Start of the parameter object  */
typedef enum 
{
    P_LONG,
    P_DOUBLE,
    P_BOOL,
    P_STRING
} p_type;

typedef struct  
{
    char *label;
    p_type type;
    double data;
} parameter;

/* End of the parameter object */

/* Start of graphics context code */
/* This is our own generic graphics context 
 * it is meant to be similar to a GC under X and DC under win32*/
typedef void (*line_t)(graphics_context *gc, int x1, int y1, int x2, int y2);   
typedef void (*out_text_t)(graphics_context *gc, int x, int y, char *text);
typedef void (*clear_display_t)(graphics_context *gc);
typedef char (*flush_t)(graphics_context *gc);
typedef int (*string_width_t)(graphics_context *gc,char *string);

struct _graphics_context{
    int width;
    int height;
    float half_text_height;  /* half the heigh of a fonts ascent */

    /* methods */
    line_t line;
    out_text_t out_text;
    clear_display_t clear_display;
    flush_t flush;
    string_width_t string_width;
};


/* End of graphics condext */

/* Start of the display_data object */
/************************************/

typedef double (*rand_t)(display_data *dd);
typedef void (*create_main_window_t)(display_data *dd,int width,int height);
typedef void (*start_t)(display_data *dd);
typedef int (*get_parms_t)(display_data *dd);
typedef void (*enable_menuitem_t)(display_data *dd,menuitem *m);
typedef void (*change_menuitem_text_t)(display_data *dd,menuitem *m);
typedef char* (*get_user_input_t)(display_data *dd, char *title, char *message,
        char *def);
typedef char* (*get_save_file_name_t)(display_data *dd,char *title, char* def);
typedef void (*show_message_t)(display_data *dd,char *message);
typedef void (*print_t)(display_data *dd);

struct _display_data{
    menubar *app_menu;
    parameter* parms;
    parameter* old_parms;
    run_data* run;

    graphics_context *gc; /* gc for default drawing area*/

    /* methods */
    rand_t rand;
    create_main_window_t create_main_window;
    start_t start;
    get_parms_t get_parms;
    enable_menuitem_t enable_menuitem; 
    change_menuitem_text_t change_menuitem_text;
    get_user_input_t get_user_input;
    get_save_file_name_t get_save_file_name;
    show_message_t show_message;
    print_t print;
}; 

/* End of the display_data object   *
 ************************************/

/* This function should start all the ui stuff */
/* The ui needs to implement this function 
 * and all the functions in the display_data struct */
display_data* init_ui(int argc,char **argv);

/* Functions implemented by popg core  */
/* This function should be called to draw */
void draw_graph(graphics_context *gc, parameter *parms,run_data *run);

#ifdef MAC
void fixmacfile(char* filename);
#endif
