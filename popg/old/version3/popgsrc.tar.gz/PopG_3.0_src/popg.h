/*
 *Copyright 1993-2003.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Educational institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */


#ifndef _SIMUL8_H_
#define _SIMUL8_H_

#define NUM_PARMS 11
/* For the parameters */
#define POP_SIZE        0
#define INIT_POP_SIZE   1
#define FIT_AA          2
#define FIT_Aa          3
#define FIT_aa          4
#define MUT_A_TO_a      5
#define MUT_a_TO_A      6
#define MIGRATION       7
#define INIT_A_FREQ     8
#define GEN_TO_RUN      9
#define LINES           10

typedef struct {
	long t1; /* The begining generation */
	long lost;
	long fixed;
	int last_saved;
	int last_saved_lines;
        double *populations;
        double **saved_pop;
} run_data;

#define DASHED_FREQ 1/40.0;

#define VTICKS 10.0 /* number of tickmarks at the left side of the graph */
#define HTICKS 5.0 /* number of tickmarks at the bottom of the graph */
#define HLINES 100.0 /* number of horizontal lines at bottom and top of graph */

#define MAX_POP_SIZE    10000
#define MAX_POPULATIONS   200
#define MAX_GEN_RUN     100000000

/* graphing variables 
 * We used to use absolute coordinates 
 * these seemingly magic numbers are just direct translations from the 
 * previous absolute coordinates into relative coordinates */
#define DEF_HEIGHT  400
#define DEF_WIDTH   650

#define DISPLAY_ASPECT_RATIO .65 /* screen absolute height/width ratio */

#define YTOP    .05
#define XEND    .85
#define YBOT    .80

#define XSPACE .05  /* convenient numbers to use as a spacer */
#define YSPACE .05  /* why these numbers, I don't know */

#define LARGE_BUF_LENGTH 500


#endif /* _SIMUL8_H_ */
