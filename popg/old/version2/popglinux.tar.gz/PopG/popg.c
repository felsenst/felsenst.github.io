/*
 *Copyright 1993-2002.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Educational institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include "popg.h"
#include "interface.h"
#include "postscript_writer.h"

#include <math.h>



typedef struct {
    double graph_height;
    double graph_width;

    double xbeg;
    double xend;
    double ytop;
    double ybot;

    double xspace;
    double yspace;
} graph_data;



char Buffer[LARGE_BUF_LENGTH];

/* function prototypes */
static long binomial(display_data *dd,long n, double pp);
static void init_run(run_data * run, parameter *parms);
static void setup_graph(graphics_context *dd, graph_data* gd, parameter *parms,
        run_data *run);
static void draw_lost_fixed(graphics_context *gc,graph_data *gd,run_data *run);
static void set_parm(parameter *parm,char *label,p_type type,double value);
static void init_parms(parameter * parms);
static void do_n_generations(display_data *gc, parameter *parms, 
        run_data * run);
char *validate_parms(parameter *parms);

char *validate_parms(parameter *parms) 
{
    if (((long)parms[INIT_POP_SIZE].data) > MAX_POP_SIZE || 
            ((long)parms[INIT_POP_SIZE].data) < 1)  {
        sprintf(Buffer, "Population Size must be between 1 and %d",
                MAX_POP_SIZE);
        return Buffer;
    }
    if (parms[FIT_AA].data < 0)
        return "Fitness of AA must be greater than or equal to 0";
    if (parms[FIT_Aa].data < 0)
        return "Fitness of Aa must be greater than or equal to 0";
    if (parms[FIT_aa].data < 0)
        return "Fitness of aa must be greater than or equal to 0";
    if (parms[MUT_A_TO_a].data > 1 || parms[MUT_A_TO_a].data < 0)
        return "Mutation rate from A to a must be between 0 and 1";
    if (parms[MUT_a_TO_A].data > 1 || parms[MUT_a_TO_A].data < 0)
        return "Mutation rate from a to A must be between 0 and 1";
    if (parms[MIGRATION].data < 0 || 
            parms[MIGRATION].data > 1.0 - 1.0/((long)parms[LINES].data)) {
         sprintf(Buffer,
       "Impossible Migration rate\nMigration rate must be between 0 and %4.2f",
                 1.0-1.0/((long)parms[LINES].data));
        return Buffer;
    }
    if (parms[INIT_A_FREQ].data > 1 || parms[INIT_A_FREQ].data < 0)
        return "The Initial Frequency of allele A must be between 0 and 1";
    if (parms[GEN_TO_RUN].data > MAX_GEN_RUN || parms[GEN_TO_RUN].data < 0) {
        sprintf(Buffer,"Generations to run must be between 0 and %d",
                MAX_GEN_RUN);
        return Buffer;
    }
    if (((long)parms[LINES].data) > MAX_POPULATIONS || 
            ((long)parms[LINES].data) < 0) {
        sprintf(Buffer,"Number of populations must be between 0 and %d",
                MAX_POPULATIONS);
        return Buffer; 
    }
    return NULL;
}

static void set_parm(parameter *parm,char *label,p_type type,double value)
{
    parm->label=label;
    parm->type=type;
    parm->data=value;
}

static void init_parms(parameter *parms)
{				/* set up default parameters */
    set_parm(parms + POP_SIZE,NULL,P_LONG,200);
    set_parm(parms + INIT_POP_SIZE,"Population Size",P_LONG,100);
    set_parm(parms + FIT_AA,"Fitness of Genotype AA",P_DOUBLE,1.0);
    set_parm(parms + FIT_Aa,"Fitness of Genotype Aa",P_DOUBLE,1.0);
    set_parm(parms + FIT_aa,"Fitness of Genotype aa",P_DOUBLE,1.0);
    set_parm(parms + MUT_a_TO_A,"Mutation From a to A (0-1)",P_DOUBLE,0.0);
    set_parm(parms + MUT_A_TO_a,"Mutation From A to a (0-1)",P_DOUBLE,0.0);
    set_parm(parms + MIGRATION,"Migration Rate between populations",P_DOUBLE,0.0);
    set_parm(parms + INIT_A_FREQ,"Initial freq. of allele A (0-1)",P_DOUBLE,0.5);
    set_parm(parms + GEN_TO_RUN,"Generations to run",P_LONG,100);
    set_parm(parms + LINES,"Number of populations evolving simultaneously",
            P_LONG,10);
}

void init_run(run_data * run, parameter* parms)
{				/* Initialize a run with parameters */
    int i;

    if (run->saved_pop != NULL) {
	for (i = 0; i <= run->last_saved_lines; i++)
	    free(run->saved_pop[i]);
	free(run->saved_pop);
    }

    run->last_saved = parms[GEN_TO_RUN].data + 1;
    run->last_saved_lines = parms[LINES].data + 1;

    run->saved_pop = calloc(run->last_saved_lines + 1, sizeof(double *));
    for (i = 0; i <= run->last_saved_lines; i++) {
	run->saved_pop[i] = calloc(run->last_saved, sizeof(double));
    }
}

/* 
 * binomial
 *   A binomial distribution 
 *   Parameters:
 *     long n:    the number of trials
 *     double pp: the probability of heads per trial
 *   Return value: the number of "heads"
 */
static long binomial(display_data *dd,long n, double pp)
{				/* binomial */
    long j, bnl;
    double p;

    if (pp <= 0.5) {
	p = pp;
    } else {
	p = 1.0 - pp;
    }
    bnl = 0;
    for (j = 1; j <= n; j++) {
	if (dd->rand(dd) < p) {
	    bnl++;
	}
    }
    if (p != pp) {
	bnl = n - bnl;
    }
    return bnl;
}				/* binomial */

static void setup_graph(graphics_context *gc,graph_data *gd, parameter *parms,
        run_data *run) 
{
    int i;
    double xspot;
    double yspot;
    double step;
    double curgen;
    
    /* draw horizontal tick marks and labels */
    for (i = 0; i <= VTICKS; i++) {
        yspot = (gd->ybot * (VTICKS - i) +  gd->ytop * i)/VTICKS;
	sprintf(Buffer, "%2.1f", i / 10.0);
        gc->line(gc,gd->xbeg - (gd->xspace * 0.5),yspot, gd->xbeg ,yspot);
        yspot += gc->half_text_height;
	gc->out_text(gc,gd->xbeg - gc->half_text_height * 4 - gd->xspace * 0.5,
                yspot, Buffer);
    }

    gc->out_text(gc,gd->xbeg - (gd->xspace*0.5) - 9 * gc->half_text_height,
            ((gd->ytop + gd->ybot) / 2) + gc->half_text_height , "P(A)");

    gc->out_text(gc, 
            gd->xbeg + (gd->xend - gd->xbeg)/2 - 5 * gc->half_text_height, 
            gd->ybot + gc->half_text_height * 4 + .6 * gd->yspace,
            "Generation");
    
    gc->line(gc,gd->xbeg,gd->ytop,gd->xbeg,gd->ybot);

    /* draw dashed lines along top and bottom of the graph area */
    for (i = 0; i < HLINES; i+=2) {
        step = (gd->graph_width)/HLINES;
        xspot = gd->xbeg + step * i ;
	gc->line(gc,xspot,gd->ytop,xspot + 5, gd->ytop);
	gc->line(gc,xspot,gd->ybot,xspot + (gd->xend - gd->xbeg)/HLINES, gd->ybot);
    }
    
    /* Draw tick marks at the bottom and labels*/
    for (i=0; i <= HTICKS ; i++)  {
        /* create hticks equally spaced partitions */
        xspot = (gd->xbeg * (HTICKS-i) + gd->xend * i)/HTICKS;

        gc->line(gc, xspot, gd->ybot, xspot,gd->ybot + 0.5 * gd->yspace);
        curgen=run->t1 + i/HTICKS * (parms[GEN_TO_RUN].data );
        if (curgen == floor(curgen))
            sprintf(Buffer,"%.0f",curgen);
        else 
            sprintf(Buffer,"%.1f",curgen);
        /* half_text_height ~ one letter width 
         * FIXME instead of using this approximation lets have an average  
         * letter width, usually width of x or some device dependant way
         * of centering text
         */
        xspot -= gc->half_text_height * strlen(Buffer)/2.0; 
        gc->out_text(gc,xspot,
                gd->ybot + .6 * gd->yspace + 2 * gc->half_text_height ,Buffer);
    }
}

static void draw_lost_fixed(graphics_context *gc,graph_data *gd, run_data *run)
{
    sprintf(Buffer, "Lost: %3ld", run->lost);
    gc->out_text(gc,gd->xend + 0.5 * gd->xspace,
            gd->ybot + gc->half_text_height / 2, Buffer);
    sprintf(Buffer, "Fixed: %3ld", run->fixed);
    gc->out_text(gc,gd->xend + 0.5 * gd->xspace,
            gd->ytop + gc->half_text_height / 2, Buffer);
}

static void init_graph(graphics_context* gc, graph_data* gd)
{
    /* This function set's up variables that position where the graph
     * goes, it checks the aspect ratio of the gc and tries to center
     * the graph and display on the display */
    double aspect;
    double vtop,vbot,vheight;
    double vleft,vright,vwidth;

    aspect = (double)gc->height / (double)gc->width;
    if ( aspect > DISPLAY_ASPECT_RATIO ) {
        /* The display high */
        vheight = gc->width * DISPLAY_ASPECT_RATIO;
        vtop = gc->height / 2 - vheight / 2;
        vbot = gc->height / 2 + vheight / 2;
        vleft = 0;
        vright = gc->width;
        vwidth = gc->width;
    }
    else {
        /* The display is wide */
        vwidth = gc->height / DISPLAY_ASPECT_RATIO;
        vleft = gc->width / 2 - vwidth / 2;
        vright = gc->width / 2 + vwidth / 2;
        vtop = 0;
        vbot = gc->height;
        vheight = gc->height;
    }
    
    gd->xspace = XSPACE * vwidth;
    gd->yspace = YSPACE * vheight;
    
    gd->ytop = vtop + YTOP * vheight;
    gd->ybot = vtop + YBOT * vheight;
    
    gd->xbeg = vleft + 10 * gc->half_text_height + 0.5 * gd->xspace;
    gd->xend = vleft + vwidth - 10 * gc->half_text_height - 0.5 * gd->xspace;
    
    gd->graph_width = gd->xend - gd->xbeg;
    gd->graph_height = gd->ybot - gd->ytop;
}

void draw_graph(graphics_context* gc, parameter *parms, run_data * run)
{
    int i,j,x,y,x1,y1;
    int t2;
    graph_data gd;
   
    gc->clear_display(gc);
    init_graph(gc,&gd);
    setup_graph(gc,&gd,parms,run);
    draw_lost_fixed(gc,&gd,run);

    /* draw the populations 
     * for any modifications made in this function similar ones 
     * should also be made in do_n_generations */
    t2 = parms[GEN_TO_RUN].data * DASHED_FREQ;
    if (t2 < 2) 
	t2 = 2;
    t2 /= 2;
    t2 *= 2; /* t2 should be even */
    for (j=0; j + 2 <= run->last_saved; j++) {
	if (j % t2 == j % (t2 / 2)) {
            x = gd.xbeg + j / ((double)run->last_saved - 1.0) * gd.graph_width;
            y = gd.ybot - gd.graph_height * run->saved_pop[0][j];
            x1 = gd.xbeg + (j+1) / ((double)run->last_saved - 1.0) * 
                gd.graph_width;
            y1 = gd.ybot - gd.graph_height * run->saved_pop[0][j+1];
            gc->line(gc,x,y,x1,y1);
        }
    }
    for (i=1; i < run->last_saved_lines; i++) {  
        for (j=0; j + 1 < run->last_saved; j++) { 
            x = gd.xbeg + gd.graph_width * j / ((double)run->last_saved - 1.0);
            y = gd.ybot - gd.graph_height * run->saved_pop[i][j];
            x1 = gd.xbeg + (j+1) / ((double)run->last_saved - 1.0) * 
                gd.graph_width;
            y1 = gd.ybot - gd.graph_height * run->saved_pop[i][j+1];
            gc->line(gc,x,y,x1,y1);
        } 
    }
}

static void do_n_generations(display_data *dd, parameter *parms, 
        run_data * run)
{
    int i, t, t2, t3;
    graph_data gd;
    graphics_context* gc= dd->gc;
    double pbar, p, p2, q, w, pp1, pp2;
    long nx, ny;

    init_graph(gc,&gd);

    if ( run->t1 == 0 ) {
        if (run->populations)
            free(run->populations);
        run->populations = malloc((parms[LINES].data + 1) * sizeof(double)); 
        for (i = 0; i <= parms[LINES].data; i++) {
            run->populations[i] = parms[INIT_A_FREQ].data;
        }
    }

    parms[POP_SIZE].data = parms[INIT_POP_SIZE].data * 2; 
    init_run(run, parms);

    /* fill in the first set */
    for (i = 1; i < run->last_saved_lines; i++) {
	run->saved_pop[i][0] = run->populations[i];
    }
    
    gc->clear_display(gc);
    setup_graph(gc,&gd,parms,run);

    /* every DASHED_FREQ of the generation run time want to draw a dash at */
    /* the expected frequency if we had an infinite population.  t2 is used */
    /* to know when we have gone 1/40 of the generation run time. */
    t2 = parms[GEN_TO_RUN].data * DASHED_FREQ;
    if (t2 < 2) 
	t2 = 2;
    t2 /= 2;
    t2 *= 2;
    t3 = parms[GEN_TO_RUN].data * 2 / gc->width; /* how often to flush */
    if (t3 < 1) 
        t3 = 1;

    /* The section below is where all the population genetics happens.
       If you are trying to understand the simulation this loop is all
       you need to know about.  The rest is input/output */

    /* for all the generations */
    for (t = 0; t < parms[GEN_TO_RUN].data; t++) {
	/* calculate the mean frequency of AA over all the populations */
	run->fixed = 0;
	run->lost = 0;
	pbar = 0.0;
	for (i = 1; i <= parms[LINES].data; i++) {
	    pbar += run->populations[i];
	    if (run->populations[i] == 0.0)
		run->lost += 1;
	    if (run->populations[i] == 1.0)
		run->fixed += 1;
	}
	pbar /= parms[LINES].data;
	/* for each population ________________________ */
	for (i = 0; i <= parms[LINES].data; i++) {/* get new frequency for population i */
	    p = (double) run->populations[i];	/* the current gene frequency */
	    p2 = p;		/* save it in p2 */
	    if (i > 0) {
		p = p * (1.0 - parms[MIGRATION].data) + parms[MIGRATION].data * pbar;
		/* all but pop. 0 receive migrants */
	    }
	    p = (1 - parms[MUT_A_TO_a].data) * p + parms[MUT_a_TO_A].data * (1 - p);

	    /* if the genotype is not fixed calculate the new frequency */
	    if (p > 0.0 && p < 1.0) {
		q = 1 - p;
		w = p * p * parms[FIT_AA].data + 2.0 * p * q * parms[FIT_Aa].data + q * q * parms[FIT_aa].data;	/* get mean fitness */
		pp1 = p * p * parms[FIT_AA].data / w;
		/* get frequency of AA after sel. */
		pp2 = 2.0 * p * q * parms[FIT_Aa].data / w;
		/* get frequency of Aa after sel. */
		if (i > 0) {
		    /* calculate the next generation */
		    nx = binomial(dd,parms[INIT_POP_SIZE].data, pp1);
		    /* draw how many AA's survive */
		    if (pp1 < 1.0 && nx < parms[INIT_POP_SIZE].data) {
			ny = binomial(dd,parms[INIT_POP_SIZE].data - nx, pp2 / (1.0 - pp1));	/* and Aa's too */
		    } else {
			ny = 0;
		    }
		    run->populations[i] = nx * 2.0 + ny;	
                    /* compute new number of A's */
		    run->populations[i] /= parms[POP_SIZE].data;	
                    /* and make it a frequency */
		} else {
		    /* calculate what the "true" average would be.  What you */
		    /* would expect with an infinite population. */
		    run->populations[i] = pp1 + pp2 / 2.0;
		}
	    }

	    /* end of the important stuff */

	    if (i > 0 || t % t2 == t % (t2 / 2)) {
		gc->line(gc,gd.xbeg + gd.graph_width * t / 
                        parms[GEN_TO_RUN].data,
		     gd.ybot - gd.graph_height * p2,
		     gd.xbeg + gd.graph_width * (t + 1) / 
                     parms[GEN_TO_RUN].data,
		     gd.ybot - gd.graph_height * run->populations[i]);
	    }

	    if (i == 0) {
                run->saved_pop[i][t] = p2;
                run->saved_pop[i][t+1] = run->populations[i];
	    }
            
            if ( i == 0 && t % t3 == 0) 
                gc->flush(gc);

	    if (i > 0) { 
                run->saved_pop[i][t+1] = run->populations[i];
	    }
	}/* end of for i<=lines : for each population _______________ */
    }	/* end of for t<g9 -- end of running through the generations */
    draw_lost_fixed(gc,&gd,run);
    gc->flush(gc);
}

static void make_menuitems_sensitive(display_data *dd) 
{
    int i,j;
    menubar *app_menu = dd->app_menu;
    menuitem *item;

    for ( i = 0 ; i < app_menu->num_menus ; i++ ) {
        for ( j = 0 ; j < app_menu->menus[i].num_items ; j++) {
            item = app_menu->menus[i].items + j;
            if ( item->enabled == FALSE )
                dd->enable_menuitem(dd,item);
        }
    }
}

static void newrun_callback(display_data *dd)
{
    char * message = NULL;
    
    dd->run->t1=0;
    do {
        dd->get_parms(dd);
        message = validate_parms(dd->parms);
        if ( message != NULL)
            dd->show_message(dd,message);
    } while (message != NULL);

    memcpy(dd->old_parms,dd->parms,NUM_PARMS * sizeof(parameter));
    do_n_generations(dd,dd->parms,dd->run);
    make_menuitems_sensitive(dd);
    sprintf(Buffer,"Continue w/%d",(int)dd->parms[GEN_TO_RUN].data);
    dd->app_menu->menus[1].items[1].label = Buffer;
    dd->change_menuitem_text(dd,&(dd->app_menu->menus[1].items[1]));
}

static void continue100_callback(display_data *dd)
{
    dd->run->t1 = dd->run->t1 + dd->parms[GEN_TO_RUN].data; 
    do_n_generations(dd,dd->parms,dd->run);
}

static void save_callback(display_data *dd)
{ 
    char *filename;
    filename = dd->get_save_file_name(dd,"Save","output.ps");
    if (filename == NULL)
        return;
    write_postscript_file(filename,dd->parms,dd->run);
    free(filename); 
}

static void print_callback(display_data *dd)
{
    dd->print(dd);
}

static void continue_callback(display_data *dd)
{ 
    int num=0;
    char *mes;
    char buffer[100];
    sprintf(buffer,"%d",(int)dd->parms[GEN_TO_RUN].data);
    while (num <= 0 ) {
        mes=dd->get_user_input(dd,"enter a number",
                "How many generations to run?", buffer);
        num=atoi(mes);
    }
    dd->run->t1 = dd->run->t1 + dd->parms[GEN_TO_RUN].data; 
    dd->parms[GEN_TO_RUN].data = num;
    do_n_generations(dd,dd->parms,dd->run);
    sprintf(Buffer,"Continue w/%d",(int)dd->parms[GEN_TO_RUN].data);
    dd->app_menu->menus[1].items[1].label = Buffer;
    dd->change_menuitem_text(dd,&(dd->app_menu->menus[1].items[1]));
}

static void restart_callback(display_data *dd)
{
    dd->run->populations = NULL;
    dd->run->t1 = 0;
    memcpy(dd->parms,dd->old_parms,NUM_PARMS * sizeof(parameter));
    do_n_generations(dd,dd->parms,dd->run);
}

static void about_callback(display_data *dd)
{
    dd->show_message(dd, "Copyright 1993-2002.  University of Washington and Joseph Felsenstein.  All\nrights reserved.  Permission is granted to reproduce, perform, and modify\nthis program.  Permission is granted to distribute or provide access to this\nprogram provided that this copyright notice is not removed, this program is\nnot integrated with or called by any product or service that generates\nrevenue, and that your distribution of this program is free.  Any modified\nversions of this program that are distributed or accessible shall indicate\nthat they are based on this program.  Educational institutions are\ngranted permission to distribute this program to their students and staff\nfor a fee to recover distribution costs.  Permission requests for any other\ndistribution of this program should be directed to license@u.washington.edu.");
 
}

static void quit_callback(display_data *dd) 
{
    exit(0);
}

static void init_menu_item(menuitem *m, char *label, BOOL enabled,
        menu_callback callback, char accelerator)
{
    m->label = label;
    m->enabled = enabled;
    m->callback = callback;
    m->accelerator = accelerator;
}


static void init_menu(menu* m, char* label, int num_items)
{
   m->label = label;
   m->num_items = num_items;
   m->items = malloc(num_items * sizeof(menuitem));
}

static void init_menubar(menubar *app_menu)
{/* Create the application menu */
    app_menu->num_menus = 2;
    app_menu->menus = malloc( 2 * sizeof(menu));

    init_menu(app_menu->menus + 0,"File",4);
    init_menu(app_menu->menus + 1,"Run",4);

    init_menu_item(app_menu->menus[0].items + 0,"Save",FALSE,
            save_callback,'S');
    init_menu_item(app_menu->menus[0].items + 1,"Print",FALSE,
            print_callback,'P');
    init_menu_item(app_menu->menus[0].items + 2,"About",TRUE,
            about_callback,'A');
    init_menu_item(app_menu->menus[0].items + 3,"Quit",TRUE,
            quit_callback,'Q');
    
    init_menu_item(app_menu->menus[1].items + 0,"Continue",FALSE,
            continue_callback,0);
    init_menu_item(app_menu->menus[1].items + 1,"Continue w/100",FALSE,
            continue100_callback,'C');
    init_menu_item(app_menu->menus[1].items + 2,"New Run",TRUE,
            newrun_callback,'N');
    init_menu_item(app_menu->menus[1].items + 3,"Restart",FALSE,
            restart_callback,'R');
    
}

int main(int argc, char **argv)
{				/* main */
    display_data *dd;
    menubar app_menu;
    parameter parms[NUM_PARMS];
    run_data run = { 0, 0, 0, 0, 0, NULL,NULL};
    init_parms(parms);
    init_menubar(&app_menu);
    dd = init_ui(argc, argv);
    dd->parms = parms;
    dd->old_parms= malloc(NUM_PARMS * sizeof (parameter));
    dd->run = &run;
    dd->app_menu = &app_menu;
    dd->create_main_window(dd,DEF_WIDTH,DEF_HEIGHT);
    dd->start(dd);
    return 0;
}
