/*
 *Copyright 1993-2002.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Education institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */

#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Core.h>
#include <X11/Xaw/Label.h>
#include <X11/Xatom.h>
#include <X11/Shell.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Dialog.h>
#include "interface.h"
#include "postscript_writer.h"

#define FONT "-*-helvetica-medium-r-normal-*-14-*"
#define NUMLABELS 11
#define NUMTEXT 10

#define LEFT_LABEL_WIDTH 450
#define TEXT_FIELD_WIDTH 250

String fallback_resources[] = {
    "*label0.label: PopG Settings", 
    "*label0.width: 705",
    "*Text*background: #FFFFFF", /* background colors */
    "*Label*background: #DDDDDD",
    "*blank_label.borderWidth: 0", /* spacer */
    "*blank_label.background: #CCFFFF",
    "*blank_label.label: ",
    "*blank_label.width: 650",
    "*ok_button.label: OK", /* all ok buttons should say OK */
    "*.Command.*.background: #DDDDFF", /* bg colors*/
    "*.form.background: #CCFFFF",
    "*.menubar.background: #CCFFFF",
    "*.MenuButton.*.background: #DDDDFF",
    "*.SmeBSBObjectClass.*.background: #DDDDFF",
    "*.input: True", /* needed to be able to type into text fields*/
    "*.editType: edit", /* edit field parameters */
    "*.displayCaret: True",
    "*.displayNonprinting: False",
    "*.drawing_area.fromVert: menubar", /* main window layout */
    "*.drawing_area.top: ChainTop",
    "*.drawing_area.bottom: ChainBottom",
    "*.menubar.orientation: horizontal",
    "*.menubar.borderWidth: 0",
    "*.menubar.left: ChainLeft",
    "*.menubar.right: ChainLeft",
    "*.menubar.bottom: ChainTop",
    "*.menubar.top: ChainTop",
    "*.input_dialog.value: ",
    NULL,
};

typedef struct {
    display_data parent;
    /* lowlevel x stuff */
    Display *display;
    int screen_number;
    int display_depth;
    Window root_window;
    /* xt widgets */
    XtAppContext appcontext;
    Widget toplevel;
    Widget parm_dialog;
    Widget dialog;
    Widget drawing_area;
    Widget *text;
    /* event loop depth */
    int depth; 
} x_display_data; 

typedef struct {
    graphics_context parent; 
    Display *display;
    int screen_number;
    Drawable d;
    Pixmap buffer; /* All our X drawing will be double buffered */
    GC x_gc;
} x_graphics_context;

static void delete_callback(Widget w, XEvent* event, String *params, 
		int *num_params);
static void redraw(Widget w,x_graphics_context *gc, XExposeEvent *ev, 
        int *cont);
static void x_get_parms(x_display_data *dd);
static void init_x_vars(x_display_data *dd);
static void parameter_to_text(parameter* parms,Widget *text);
static void text_to_parameter(parameter* parms,Widget *text);
static void setup_callbacks(x_display_data *dd);
static void x_line(x_graphics_context *gc,int x1,int y1,int x2,int y2);
static void x_out_text(x_graphics_context *gc,int x,int y,char *text);
static void x_clear_display(x_graphics_context *gc);
static void parm_ok_callback(Widget *not_used,x_display_data *dd);
static void event_loop(x_display_data *dd);
static void x_show_message(x_display_data *dd,char *message);
static void layout_toplevel(x_display_data *dd, menubar *app_menu,int width,
        int height);
static char* x_get_user_input(x_display_data *dd, char *title, char *message,
        char *def);
static void x_create_main_window(x_display_data *dd,int width, int height);
static void x_print(x_display_data *dd);
static void setup_fonts(x_graphics_context *gc);
static char* x_get_save_file_name(x_display_data *dd,char *title, char* def);
static void x_change_menuitem_text(x_display_data *dd,menuitem *m);
void dialog_delete(Widget w, XEvent* event, String *params, int *num_params);
static void setup_delete_callback(x_display_data *dd,Widget window, 
        XtActionProc callback);

static void x_change_menuitem_text(x_display_data *dd,menuitem *m)
{
    XtVaSetValues(m->app_data,"label",m->label,NULL);
}

static char* x_get_save_file_name(x_display_data *dd,char *title, char* def)
{
    return x_get_user_input(dd,title,"Enter Save File Name",def); 
}
static void x_enable_menuitem(x_display_data *dd,menuitem* m) 
{
    XtVaSetValues(m->app_data,"sensitive",TRUE,0);
    m->enabled = TRUE;
}


static void dismiss_input(Widget *not_used,x_display_data *dd)  
{
    dd->depth--;
}

static char* x_get_user_input(x_display_data *dd, char *title, char *message, 
        char* def)
{ 
    Widget dialog;
    char *ret;
    Arg wargs[10];
    int i;
 
    dd->dialog = XtCreatePopupShell(title,transientShellWidgetClass,
            dd->toplevel, NULL,0);
    i = 0;
    XtSetArg(wargs[i],"label",message);                 i++;
    XtSetArg(wargs[i],"value",def);                     i++;
    dialog = XtCreateManagedWidget("input_dialog",dialogWidgetClass,
            dd->dialog, wargs,i);
    XawDialogAddButton(dialog,"ok_button",(XtCallbackProc)dismiss_input,dd);
    XtPopupSpringLoaded(dd->dialog);
    setup_delete_callback(dd,dd->dialog, (XtActionProc)dialog_delete);
    event_loop(dd);
    ret = strdup(XawDialogGetValueString(dialog));
    XtPopdown(dd->dialog);
    XtDestroyWidget(dd->dialog);
    return ret;
}

static void parm_ok_callback(Widget *not_used,x_display_data *dd) 
{       
    text_to_parameter(dd->parent.parms,dd->text);     
    XtPopdown(dd->parm_dialog);
    dd->depth--;
}
             

static void parameter_to_text(parameter* parms,Widget *text) 
{
    int i,nullcount=0;
    char buf[100];
    
    sprintf(buf,"%g",parms[0].data/2);
    XtVaSetValues(text[0],XtNstring,buf,NULL);
    for ( i = 0 ; i < NUM_PARMS ; i++ ) { 
        switch ( parms[i].type) {
            case P_LONG:
                sprintf(buf,"%ld",(long)(parms[i].data));
                break;
            case P_DOUBLE:
                sprintf(buf,"%f",parms[i].data);
                break;
            case P_BOOL: /* not handled yet*/
            case P_STRING:
                break;
        }
        if ( parms[i].label == NULL) {
            nullcount++;
            continue;
        }
        XtVaSetValues(text[i-nullcount],XtNstring,buf,NULL);
    }
}

static void text_to_parameter(parameter* parms,Widget *text) 
{
    int i,nullcount=0;
    XtPointer dp;
    
    for ( i = 0 ; i < NUM_PARMS ; i++ ) { 
        if ( parms[i].label == NULL) {
            nullcount++;
            continue;
        }
        XtVaGetValues(text[i-nullcount],XtNstring,&dp,NULL);
        switch ( parms[i].type) {
            case P_LONG:
                parms[i].data = atoi((char*)dp);
                break;
            case P_DOUBLE:
                parms[i].data = atof((char*)dp);
                break;
            case P_BOOL: /* not handled yet*/
            case P_STRING:
                break;
        }
    }
    /* FIXME this shouldn't be here */
}

static void x_get_parms(x_display_data *dd) 
{
    Arg wargs[10];
    Widget label[NUMLABELS];
    Widget ok_button;
    Widget blank_label;
    char buffer[10];
    Widget form;
    int nullcount=0;
    int i = 0,j = 0;

    if (dd->parm_dialog != 0) {
        XtMapWidget(dd->parm_dialog);
        XtPopup(dd->parm_dialog,XtGrabExclusive);
        event_loop(dd);
        return;
    }

    dd->text = malloc(NUMTEXT * sizeof(Widget));

    /* Create The Dialog */
    dd->parm_dialog = XtCreatePopupShell("Parameters",
                    transientShellWidgetClass, dd->toplevel,NULL,0);
    form = XtCreateManagedWidget("form",formWidgetClass,dd->parm_dialog,
                    NULL,0);
    
    /* Create The Labels */
    i = 0;
    XtSetArg(wargs[i],"top",XawChainTop);               i++;
    XtSetArg(wargs[i],"bottom",XawChainTop);            i++;
    XtSetArg(wargs[i],"left",XawChainLeft);             i++;
    XtSetArg(wargs[i],"right",XawChainLeft);            i++;
    nullcount=0;
    
    for (j = 0; j <= NUM_PARMS ; j++) {
        if ( j > 0)  {
            if (dd->parent.parms[j-1].label == NULL) {
                nullcount++;
                continue;
            }
            XtSetArg(wargs[4],"label",dd->parent.parms[j-1].label);
            XtSetArg(wargs[5],"width",LEFT_LABEL_WIDTH);
            i = 6;
        }
        sprintf(buffer,"label%d",j-nullcount);
        label[j-nullcount] = 
            XtCreateManagedWidget(buffer,labelWidgetClass,form, wargs,i);
    }

    /* Create the text boxes */
    i = 0;
    XtSetArg(wargs[i],"top",XawChainTop);               i++;
    XtSetArg(wargs[i],"bottom",XawChainTop);            i++;
    XtSetArg(wargs[i],"left",XawRubber);                i++;
    XtSetArg(wargs[i],"right",XawChainRight);           i++;
    XtSetArg(wargs[i],"fromHoriz",label[1]);            i++;
    XtSetArg(wargs[i],"width",TEXT_FIELD_WIDTH);        i++;
    for (j = 0 ; j < NUMTEXT; j++) {
            sprintf(buffer,"text%d",j);
            dd->text[j] = XtCreateManagedWidget(buffer,asciiTextWidgetClass,
                            form, wargs,i);
    }

    /* position the labels */
    for (j = 0; j < NUMLABELS ; j++)    {
            if (j == 0) continue;
            else XtVaSetValues(label[j],"fromVert",label[j-1],NULL);
    }

    /* position the text boxes */
    for (j = 0 ; j < NUMTEXT; j++) {
                    XtVaSetValues(dd->text[j],"fromVert",label[j],NULL);
    }   
    
    /* add the ok button */
    i = 0;
    XtSetArg(wargs[i],"top",XawChainTop);                       i++;
    XtSetArg(wargs[i],"bottom",XawChainTop);                    i++;
    XtSetArg(wargs[i],"left",XawRubber);                        i++;
    XtSetArg(wargs[i],"right",XawChainRight);                   i++;
    XtSetArg(wargs[i],"fromVert",dd->text[NUMTEXT-1]);          i++;
    blank_label = XtCreateManagedWidget("blank_label",labelWidgetClass,form,
                    wargs,i);
    XtSetArg(wargs[i],"fromHoriz",blank_label);                 i++;
    ok_button = XtCreateManagedWidget("ok_button",commandWidgetClass,form,
                    wargs,i);
    XtAddCallback(ok_button, XtNcallback,(XtCallbackProc)parm_ok_callback
                    ,dd);

    /* load the parameters */
    parameter_to_text(dd->parent.parms,dd->text);

    /* show it */
    XtPopup(dd->parm_dialog,XtGrabExclusive);
    setup_delete_callback(dd,dd->parm_dialog, (XtActionProc)dialog_delete);
    event_loop(dd);
}

void dialog_delete(Widget w, XEvent* event, String *params,
		int *num_params)
{
}

void delete_callback(Widget w, XEvent* event, String *params,
		int *num_params)
{
	exit(0);
}

static void x_flush(x_graphics_context *gc) {
    XFlush(gc->display);
    redraw(NULL,gc,NULL,NULL);
}

static double x_rand(x_display_data *dd) {
    return (((double) (random())) / (double) RAND_MAX);	
}

static void resize(Widget w,x_display_data *dd, XEvent *ev, int* cont)
{
    Window i;
    int j,k,l,m,width,height;
    XGetGeometry(dd->display,XtWindow(dd->drawing_area),&i,&j,&k,
            &width, &height,&l,&m); 
    dd->parent.gc->width=width;
    dd->parent.gc->height=height;
    draw_graph(dd->parent.gc,dd->parent.parms,dd->parent.run);
}

static void redraw(Widget w,x_graphics_context *gc, XExposeEvent *ev,int* cont) 
{
    if (gc->buffer) 
        XCopyArea(gc->display,gc->buffer,gc->d, gc->x_gc,0,0,gc->parent.width,
                gc->parent.height,0,0);	
}

static void x_line(x_graphics_context *gc,int x1,int y1,int x2,int y2)
{ 
    XDrawLine(gc->display,gc->buffer,gc->x_gc,x1,y1,x2,y2);
} /* line */

void x_out_text(x_graphics_context *gc,int x,int y,char *text)
{ 
    XDrawString(gc->display,gc->buffer,gc->x_gc, x,y,text,strlen(text));
} /* out_text */

void x_clear_display(x_graphics_context *gc)
{
	XGCValues values;
	values.foreground = WhitePixel(gc->display,gc->screen_number);
        XChangeGC(gc->display,gc->x_gc,GCForeground,&values);
        XSetFillStyle(gc->display,gc->x_gc,FillSolid);
        XFillRectangle(gc->display,gc->buffer,gc->x_gc,0,0,gc->parent.width,
                gc->parent.height);
	values.foreground = BlackPixel(gc->display,gc->screen_number);
        XChangeGC(gc->display,gc->x_gc,GCForeground,&values);
}

static x_graphics_context* create_gc(x_display_data *dd, Drawable d) 
{
    XGCValues values;
    x_graphics_context *gc;
    Window i;
    int j,k,l,m; /* dummy */
    int width, height;
    
    gc = malloc(sizeof(x_graphics_context));
    values.foreground = BlackPixel(dd->display,dd->screen_number);
    gc->display = dd->display;
    gc->d = d;
    gc->screen_number = dd->screen_number;
    gc->x_gc = XCreateGC(dd->display,d,GCForeground, &values);
    XGetGeometry(dd->display,d,&i,&j,&k,&(gc->parent.width),
            &(gc->parent.height),&l,&m); 
    XGetGeometry(dd->display,dd->root_window,&i,&j,&k,&width, &height,&l,&m); 
    gc->buffer = XCreatePixmap(dd->display,d,width,height,dd->display_depth);
    x_clear_display(gc);
    setup_fonts(gc);
   
    gc->parent.line = (line_t)x_line;
    gc->parent.out_text = (out_text_t)x_out_text;
    gc->parent.clear_display = (clear_display_t)x_clear_display;
    gc->parent.flush = (flush_t)x_flush;
 
    return gc;
}

static void init_x_vars(x_display_data *dd)
{
    XtRealizeWidget(dd->toplevel);
    dd->display = XtDisplay(dd->toplevel);
    dd->screen_number = XScreenNumberOfScreen(XtScreen(dd->toplevel));
    dd->display_depth = DefaultDepth(dd->display, dd->screen_number);
    dd->root_window = DefaultRootWindow(dd->display);
}

static void setup_delete_callback(x_display_data *dd,Widget window, 
        XtActionProc callback)
{
        static int i=0;
	Atom wm_delete_window;
	XtActionsRec draw_actions[] = {
		{ "", callback },
	};
        char buffer[100];
        char buffer2[100];

        sprintf(buffer,"quit%d",i);
        draw_actions[0].string = buffer;
	XtAppAddActions(dd->appcontext,draw_actions,1);

        sprintf(buffer2,"<Message>WM_PROTOCOLS: %s()",buffer);
	XtOverrideTranslations(window,XtParseTranslationTable 
			(buffer2));
	wm_delete_window = XInternAtom(dd->display, "WM_DELETE_WINDOW",0);
	XSetWMProtocols(dd->display,XtWindow(window), 
			&(wm_delete_window),1);
}

static void setup_fonts(x_graphics_context *gc) 
{
	char *fontname;
	XGCValues values;
        XFontStruct *fontst;

	fontname = XGetDefault(gc->display,"PopG","font");

	fontst = XLoadQueryFont(gc->display,FONT);
	if (fontst == NULL && fontname != NULL) 
		fontst = XLoadQueryFont(gc->display,fontname);
	if (fontst == NULL) 
		fontst = XLoadQueryFont(gc->display,"fixed");
	if (fontst == NULL) {
		gc->parent.half_text_height = 6;
		return; 
		/* Just use whatever font the gc has and hope for the best 
                 * really shouldn't get here */
	}
	gc->parent.half_text_height = (fontst->ascent + 1) / 2;
	values.font = fontst->fid;
	XChangeGC(gc->display,gc->x_gc,GCFont,&values);
        XFreeFontInfo(NULL,fontst,0);
}

static void setup_callbacks(x_display_data *dd) 
{
    dd->parent.rand = (rand_t)x_rand;
    dd->parent.create_main_window = (create_main_window_t)x_create_main_window;
    dd->parent.start = (start_t)event_loop;
    dd->parent.get_parms = (get_parms_t)x_get_parms;
    dd->parent.enable_menuitem = (enable_menuitem_t)x_enable_menuitem;
    dd->parent.change_menuitem_text = (change_menuitem_text_t)
        x_change_menuitem_text; 
    dd->parent.get_user_input = (get_user_input_t)x_get_user_input;
    dd->parent.print = (print_t)x_print;
    dd->parent.show_message = (show_message_t)x_show_message;
    dd->parent.get_save_file_name = (get_save_file_name_t)x_get_save_file_name;
}

static void event_loop(x_display_data *dd) 
{
    int i = dd->depth;
    XEvent event;
    dd->depth++;
    while (i != dd->depth) {
        XtAppNextEvent(dd->appcontext,&event);
        XtDispatchEvent(&event);
    }
}

static void dismiss_message(Widget *not_used,x_display_data *dd) 
{
   XtDestroyWidget(dd->dialog);
   dd->depth--;
}

static void x_show_message(x_display_data *dd,char * message )
{
    Widget dialog;
    Arg wargs[10];
    int i;
 
    dd->dialog = XtCreatePopupShell("Message",transientShellWidgetClass,
            dd->toplevel, NULL,0);
    i = 0;
    XtSetArg(wargs[i],"label",message);                 i++;
    dialog = XtCreateManagedWidget("dialog",dialogWidgetClass,dd->dialog,
            wargs,i);
    XawDialogAddButton(dialog,"ok_button",(XtCallbackProc)dismiss_message,dd);
    XtPopupSpringLoaded(dd->dialog);
    setup_delete_callback(dd,dd->dialog, (XtActionProc)dialog_delete);
    event_loop(dd);
}

static void menuitem_callback(Widget w,x_display_data *dd) 
{
    int i,j;
    menubar* app_menu = dd->parent.app_menu;
    menuitem *item;
    for ( i = 0 ; i < app_menu->num_menus ; i++) {
        for ( j = 0 ; j < app_menu->menus[i].num_items ; j++ ) {
            item = app_menu->menus[i].items + j;
            if (item->app_data == w)
                if ( item->callback != NULL )
                    item->callback((display_data*)dd);
        }
    }
}

static void layout_toplevel(x_display_data *dd, menubar *app_menu,int width,
        int height) 
{
    Arg wargs[7];
    Widget form;
    Widget menub;
    Widget menubutton;
    Widget xt_menu;
    Widget entry;
    int i,j;

    form = XtCreateManagedWidget("form",formWidgetClass,dd->toplevel,NULL,0);
    menub = XtCreateManagedWidget("menubar",boxWidgetClass,form,NULL,0);
    XtSetArg(wargs[0],XtNwidth,width);
    XtSetArg(wargs[1],XtNheight,height);
    dd->drawing_area = XtCreateManagedWidget("drawing_area",coreWidgetClass,
            form, wargs,2);

    /* setup menus */
    for ( i = 0 ; i < app_menu->num_menus ; i++) {
        menubutton = XtCreateManagedWidget (app_menu->menus[i].label,
                menuButtonWidgetClass,menub, NULL,0);
        xt_menu = XtCreatePopupShell("menu",simpleMenuWidgetClass,menubutton,
                NULL, 0);
        for ( j = 0 ; j < app_menu->menus[i].num_items ; j++ ) {
            entry = XtVaCreateManagedWidget(app_menu->menus[i].items[j].label, 
                    smeBSBObjectClass,xt_menu, "sensitive", 
                    app_menu->menus[i].items[j].enabled,NULL);
            app_menu->menus[i].items[j].app_data = entry;
            XtAddCallback(entry,XtNcallback,(XtCallbackProc)menuitem_callback,
                    dd);
        }
    }
}

static void x_print(x_display_data *dd)
{
    print_postscript_file(dd->parent.parms,dd->parent.run);
}

static void x_create_main_window(x_display_data *dd,int width,int height)
{
    layout_toplevel(dd,dd->parent.app_menu,width,height); 
    init_x_vars(dd);
    XtMapWidget(dd->toplevel);
    setup_delete_callback(dd,dd->toplevel, (XtActionProc)delete_callback);
    dd->parent.gc = (graphics_context*)create_gc(dd,XtWindow(dd->drawing_area));
    XtAddEventHandler(dd->drawing_area,ExposureMask,0,
            (XtEventHandler)redraw, dd->parent.gc);
    XtAddEventHandler(dd->drawing_area,StructureNotifyMask,FALSE,
            (XtEventHandler)resize,dd);
    draw_graph(dd->parent.gc,dd->parent.parms,dd->parent.run);
    redraw(NULL,(x_graphics_context*)dd->parent.gc,NULL,NULL);
}

display_data* init_ui(int argc,char **argv)
{ 
    x_display_data *dd;

    srandom(time(NULL));
    dd = calloc(1,sizeof(x_display_data));
    setup_callbacks(dd);
    dd->toplevel = XtAppInitialize(&(dd->appcontext),argv[0],NULL,0,&argc,
                    argv,fallback_resources,NULL,0);
    dd->depth = 0;
    dd->parm_dialog = 0;
    return (display_data*)dd;
}
