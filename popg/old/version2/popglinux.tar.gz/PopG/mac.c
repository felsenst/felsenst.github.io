/*
 *Copyright 1993-2002.  University of Washington and Joseph Felsenstein.  All
 *rights reserved.  Permission is granted to reproduce, perform, and modify
 *this program.  Permission is granted to distribute or provide access to this
 *program provided that this copyright notice is not removed, this program is
 *not integrated with or called by any product or service that generates
 *revenue, and that your distribution of this program is free.  Any modified
 *versions of this program that are distributed or accessible shall indicate
 *that they are based on this program.  Educational institutions are
 *granted permission to distribute this program to their students and staff
 *for a fee to recover distribution costs.  Permission requests for any other
 *distribution of this program should be directed to license@u.washington.edu.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "interface.h"

/* Constants */
const Rect resize_bounds = { 200,200,16000,16000};
const Rect big_rect = { 0, 0, 16000, 16000};

/* Structs */
typedef struct {
    display_data parent;
    WindowPtr mainwin;
    DialogPtr parm_dialog;
    int parm_last;
    int last;
    int loop;
    char *filename;
} mac_display_data; 

typedef struct {
    graphics_context parent; 
    WindowPtr win;
    int xoffset;
    int yoffset;
} mac_graphics_context;

/* prototypes */
static void setup_callbacks(mac_display_data *dd);
static void mac_create_main_window(mac_display_data *dd,int width, int height);
static void mac_start(mac_display_data *dd);
static void setup_menus(mac_display_data *dd);
static unsigned char* c_to_p(char *str);
static void handle_menu(mac_display_data *dd,int menu);
static void handle_resize(mac_display_data *dd,EventRecord ev);
static void mac_line(mac_graphics_context *gc, int x1, int y1, int x2, int y2);
static void setup_main_gc(mac_display_data *dd,int width, int height);
static void paint_mainwin(mac_display_data *dd);
static void mac_clear_display(mac_graphics_context *gc);
static void mac_line(mac_graphics_context *gc, int x1, int y1, int x2, int y2);
static int mac_get_parms(mac_display_data *dd);
static void paint_dialog(WindowPtr dlg);
static void setup_parm_dialog(mac_display_data *dd);
static void do_dlg_mouse_click(mac_display_data *dd,EventRecord ev,int where, WindowPtr win);
static void fixmacfile(char* filename);

static void p_to_c(char *buf) 
{
	int i,j;
	
	j=buf[0];
	for ( i = 0 ; i < j ; i++)
		buf[i] = buf[i+1];
	buf[i]=j;
}

static void retrieve_parms(mac_display_data *dd)
{
	int i,controlnum,nullskipper = 0;
	char buffer[255];
	Handle h;
	short item_type;
	Rect r;

	for ( i=0 ; i < NUM_PARMS ; i++) {
		if (dd->parent.parms[i].label == NULL) {
			nullskipper++;
			continue;
		}
		controlnum = (i-nullskipper+1) * 2;
		GetDialogItem(dd->parm_dialog,controlnum,&item_type,&h,&r);
		GetDialogItemText(h,(unsigned char*)buffer);
		p_to_c(buffer);
		if (dd->parent.parms[i].type == P_LONG)
			dd->parent.parms[i].data = atoi(buffer);
		else
			dd->parent.parms[i].data = atof(buffer);
	}
}


static void paint_dialog(WindowPtr dlg) 
{
	BeginUpdate(dlg);
	UpdateDialog(dlg,dlg->visRgn);
	EndUpdate(dlg);
}

static void handle_dlg_event(mac_display_data *dd,WindowPtr dlg)
{ 
	EventRecord ev;
	int ok,where;
	WindowPtr win;
	short item;
	char key;

	dd->loop = 1;
	while (dd->loop == 1) {
		ok = GetNextEvent(everyEvent,&ev);
		where = FindWindow(ev.where,&win);
		if (ok == 0)
			DialogSelect(&ev,&win,&item); 
		if (ev.what == mouseDown && win == dlg) 
			do_dlg_mouse_click(dd,ev,where,dlg);
		else if (ev.what == updateEvt && win == dlg) 
			paint_dialog(dlg);
		else if (ev.what == updateEvt && win == dd->mainwin)
			paint_mainwin(dd);
		else if (ev.what == keyDown) {
			key = (char)(ev.message & charCodeMask);
			if ( key == '\r' ) {
				HideWindow(dlg);
				dd->loop = 0;
			}
			else DialogSelect(&ev,&dlg,&item);
		}
		else DialogSelect(&ev,&dlg,&item);
	}		
}

static int mac_get_parms(mac_display_data *dd)
{
	if (dd->parm_dialog == NULL)
		setup_parm_dialog(dd);
	ShowWindow(dd->parm_dialog);
	SelectWindow(dd->parm_dialog);
	paint_dialog(dd->parm_dialog);
	dd->last = dd->parm_last;
	handle_dlg_event(dd,dd->parm_dialog);
	retrieve_parms(dd);
	return 1;
}

static void setup_parm_dialog(mac_display_data *dd)
{
	Rect win_rect = {60,30,90,393};	
	unsigned char *tmp;
	Handle text,buttons;
	int i,nullskipper=0,controlnum;
	short item_type;
	Handle h;
	Rect r;
	char buffer[100];


	tmp = c_to_p("Settings");
	dd->parm_dialog = GetNewDialog(130,NULL,(void*)-1);
	text = GetResource('DITL',128);
	for (i = 0 ; i < NUM_PARMS ; i++) {
		if (dd->parent.parms[i].label == NULL) {
			nullskipper++;
			continue;
		}
		AppendDITL(dd->parm_dialog,text,appendDITLBottom);
		controlnum = (i-nullskipper) * 2 +1;
		GetDialogItem(dd->parm_dialog,controlnum,&item_type,&h,&r);
		tmp = c_to_p(dd->parent.parms[i].label);
		SetDialogItemText(h,tmp);
		free(tmp);
		controlnum++;
		GetDialogItem(dd->parm_dialog,controlnum,&item_type,&h,&r);
		sprintf(buffer,"%g",dd->parent.parms[i].data);
		tmp = c_to_p(buffer);
		SetDialogItemText(h,tmp);
		free(tmp);
	}
	
	dd->parm_last = (i-nullskipper) * 2 + 1;
	buttons = GetResource('DITL',129);
	AppendDITL(dd->parm_dialog,buttons,appendDITLBottom);
	free(tmp);
}

static void paint_mainwin(mac_display_data *dd)
{
    BeginUpdate(dd->mainwin);
    SetPort((void*)dd->mainwin);
    EraseRect(&big_rect);
    PenSize(1,1);
    draw_graph((graphics_context *)(dd->parent.gc),dd->parent.parms,dd->parent.run);
    EndUpdate(dd->mainwin);
}

static void handle_resize(mac_display_data *dd,EventRecord ev)
{
    long windowsize;
    windowsize = GrowWindow(dd->mainwin,ev.where,&resize_bounds);
    if (windowsize != 0) {
        SizeWindow(dd->mainwin,LoWord(windowsize),HiWord(windowsize),TRUE);
	dd->parent.gc->width = LoWord(windowsize);
	dd->parent.gc->height = HiWord(windowsize);
	InvalRect(&big_rect);
    }
}


static void handle_menu(mac_display_data *dd,int menu)
{
   int m = HiWord(menu);
   int i = LoWord(menu);
   if (dd->parent.app_menu->num_menus >= m && m >= 0 &&
           dd->parent.app_menu->menus[m-1].num_items >= i && i > 0)
           if (dd->parent.app_menu->menus[m-1].items[i-1].callback != NULL)
		       dd->parent.app_menu->menus[m-1].items[i-1].callback((display_data*)dd);
   HiliteMenu(0);
}

static unsigned char* c_to_p(char *str) 
{
    unsigned char* ret;
    ret = malloc(strlen(str) + 2);
    ret[0] = strlen(str);
    strcpy((char *)ret + 1,str);
    return ret;
}

static unsigned char* escape_menu_string(menuitem *m)
{
	unsigned char* ret;
	int i,j;

	ret = malloc(strlen(m->label)*2 + 4);

	ret++;
	for ( i = 0, j = 0 ; i < strlen(m->label) ; i++,j++) {
		if (m->label[i] == '/' ) {
			ret[j] = '\\'; /* There should be a better way to escape a / */
			continue;
		}
		ret[j] = m->label[i];
	}
	ret[j] = '/';
	ret[j+1] = m->accelerator;
	ret[j+2] = 0;
	*(ret - 1) = strlen((char*)ret);
	ret--;
	return ret;
}

static void enable_disable_menus(menubar *mbar) 
{
	int i;
	int j;
	MenuHandle mh;

	for ( i = 0 ;  i < mbar->num_menus ; i++ ) {
		mh = GetMenuHandle(i+1);
		for ( j = 0 ;  j < mbar->menus[i].num_items ; j++ ) {
			if (mbar->menus[i].items[j].enabled == TRUE)	
				EnableItem(mh,j+1);
			else
				DisableItem(mh,j+1);
				
		}
	}
    	DrawMenuBar();
}


static void setup_menus(mac_display_data *dd) 
{   
	MenuRef m;
	unsigned char *tmp;
	int i,j,k=0;
	Handle m_bar;
	menubar *app_menu = dd->parent.app_menu;
	m_bar = GetNewMBar(128);
	SetMenuBar(m_bar);
   
	for ( i = 0 ; i < app_menu->num_menus ; i++) {
		tmp = c_to_p(app_menu->menus[i].label);
		m = NewMenu(i + 1,tmp);
		free(tmp);
		for ( j = 0 ; j < app_menu->menus[i].num_items ; j++) {
			tmp = escape_menu_string(&(app_menu->menus[i].items[j]));
			AppendMenu(m,tmp);
			free(tmp);
			SetItemCmd(m,i-1,app_menu->menus[i].items[j].accelerator);
		}
		InsertMenu(m,0);
	}
	AppendResMenu(GetMenuHandle(128) , 'DRVR');
	enable_disable_menus(app_menu);
	DrawMenuBar();
}


static void do_mainwin_mouse_click(mac_display_data *dd,EventRecord ev,int where)
{
	if (where == inGoAway) {
		if ( TrackGoAway (dd->mainwin, ev.where))
			HideWindow(dd->mainwin);
	}
	else if (where == inDrag)
		DragWindow(dd->mainwin, ev.where, &big_rect);
	else if (where == inGrow)
		handle_resize(dd,ev);
	else if (where == inSysWindow)
		SystemClick(&ev,dd->mainwin);
	else if (where == inMenuBar)
		handle_menu(dd,MenuSelect(ev.where));
}

static void do_dlg_mouse_click(mac_display_data *dd,EventRecord ev,int where,WindowPtr win)
{
	short item;
	if (where == inSysWindow) {
		SystemClick(&ev,win);
		DialogSelect(&ev,&win,&item); 
	}
	else if (where == inDrag)
		DragWindow(win, ev.where, &big_rect);
	else {
		DialogSelect(&ev,&win,&item); 
		if (item == dd->last) {
			HideWindow(win);
			dd->loop = 0;
		}
	}
}

static double mac_rand() 
{
	return (((double)rand())/RAND_MAX);
}

static void handle_key_down(mac_display_data *dd, EventRecord *ev)
{
	char key;
	int i,j;
	menubar *app_menu = dd->parent.app_menu;

	key = (char)(ev->message & charCodeMask);
	if ( ev->modifiers & cmdKey ) {
		for ( i = 0 ; i < app_menu->num_menus ; i++) {
			for ( j = 0 ; j < app_menu->menus[i].num_items ; j++) {
				if ( toupper(app_menu->menus[i].items[j].accelerator) == toupper(key) && 
						app_menu->menus[i].items[j].enabled)
					app_menu->menus[i].items[j].callback((display_data*)dd);
			}
		}
	}
}

static void mac_start(mac_display_data *dd)
{
	EventRecord ev;
	int ok,where;
	WindowPtr win;

	while (true) {
		ok = GetNextEvent(everyEvent,&ev);
		if (dd->filename) {
			fixmacfile(dd->filename);
			dd->filename = NULL;
		}
		where = FindWindow(ev.where,&win);
		if (ev.what == updateEvt)
			paint_mainwin(dd);
		else if (ev.what == mouseDown)
			do_mainwin_mouse_click(dd,ev,where);
		else if (ev.what == mouseDown && where == inSysWindow)
			SystemClick(&ev,win);
		else if (ev.what == mouseDown && where == inMenuBar)
			handle_menu(dd,MenuSelect(ev.where));
		else if (ev.what == keyDown) {
			handle_key_down(dd,&ev);
		}
	}

}

static void mac_line(mac_graphics_context *gc, int x1, int y1, int x2, int y2)
{
	SetPort((GrafPtr)gc->win);
	MoveTo(x1 + gc->xoffset,y1 + gc->yoffset);
	LineTo(x2 + gc->xoffset,y2 + gc->yoffset);
}

static void mac_out_text(mac_graphics_context *gc, int x, int y, char* text)
{
	unsigned char *tmp;
  	SetPort((GrafPtr)gc->win);
	MoveTo(x + gc->xoffset,y + gc->yoffset);
	tmp = c_to_p(text);
	DrawString(tmp);
	free(tmp);
}

static void mac_clear_display(mac_graphics_context *gc)
{
	SetPort((GrafPtr)gc->win);
	EraseRect(&big_rect);
}

static void mac_flush(mac_graphics_context *gc)
{
	if (gc->xoffset == 0) {
		ShowWindow(gc->win);
		SelectWindow(gc->win);
	}
}

static void setup_main_gc(mac_display_data *dd, int width, int height) 
{
    mac_graphics_context *gc;

    gc = malloc (sizeof(mac_graphics_context));
    gc->win = dd->mainwin;
    gc->parent.height = height;
    gc->parent.width = width;
    gc->parent.half_text_height = 6;
    gc->parent.line = (line_t)mac_line;
    gc->parent.out_text = (out_text_t)mac_out_text;
    gc->parent.clear_display = (clear_display_t)mac_clear_display;
    gc->parent.flush = (flush_t)mac_flush;
    gc->xoffset = 0;
    gc->yoffset = 0;
    dd->parent.gc = (graphics_context*)gc;
}

static void mac_create_main_window(mac_display_data *dd,int width, int height)
{
    unsigned char *tmp;
    Rect gfxBounds = {50,10,400,260};
    gfxBounds.bottom= height + 50;
    gfxBounds.right= width + 10;
    
    tmp = c_to_p("PopG");
    dd->mainwin = NewCWindow (NULL,&gfxBounds, tmp, 0, documentProc,
            (WindowPtr) - 1L, true, 0);
    free(tmp);
    setup_main_gc(dd,width,height);
    ShowWindow(dd->mainwin);
    SelectWindow(dd->mainwin);
    InvalRect(&big_rect);
    setup_menus(dd); 
}

static char* mac_get_user_input(mac_display_data *dd,char *title, char *message, char *def)
{
	WindowPtr dlg;
	unsigned char *tmp;
	Handle h;
	short item_type;
	Rect r;
	char buffer[100];

	dlg = GetNewDialog(131,NULL,(void*)-1);
	dd->last = 3;
	
	tmp=c_to_p(title);
	SetWTitle(dlg,tmp);
	free(tmp);

	GetDialogItem(dlg,1,&item_type,&h,&r);
	tmp = c_to_p(message);
	SetDialogItemText(h,tmp);
	free(tmp);	

	GetDialogItem(dlg,2,&item_type,&h,&r);
	tmp = c_to_p(def);
	SetDialogItemText(h,tmp);
	free(tmp);	


	ShowWindow(dlg);
	SelectWindow(dlg);
	paint_dialog(dlg);
	handle_dlg_event(dd,dlg);

	GetDialogItem(dlg,2,&item_type,&h,&r);
	GetDialogItemText(h,(unsigned char*)buffer);

	buffer[buffer[0] + 1] = 0;

	return (char*)strdup(buffer + 1);
}

static void mac_show_message(mac_display_data *dd,char* message) 
{
	WindowPtr dlg;
	unsigned char *tmp;
	Handle h;
	short item_type;
	Rect r;
	
	if (strlen(message) > 255) {
		dlg = GetNewDialog(133,NULL,(void*)-1);
		
	}
	else {
		dlg = GetNewDialog(132,NULL,(void*)-1);
		GetDialogItem(dlg,1,&item_type,&h,&r);
		tmp = c_to_p(message);
		SetDialogItemText(h,tmp);
		free(tmp);	
	}

	ShowWindow(dlg);
	SelectWindow(dlg);
	paint_dialog(dlg);
	dd->last = 2;
	handle_dlg_event(dd,dlg);

}

static void mac_print(mac_display_data *dd)
{
	THPrint prhandle;
	mac_graphics_context gc;

	prhandle = (THPrint)NewHandleClear(sizeof(TPrint));

	if (prhandle == NULL)
		return;
	
	PrintDefault(prhandle);
  
	PrOpen();
  	if (PrJobDialog(prhandle) == FALSE) {
		PrClose();
		return;
	}
	else if (PrStlDialog(prhandle) == FALSE) {
		PrClose();
		return;
	}

	gc.win =(GrafPort*) PrOpenDoc(prhandle,NULL,NULL);	
	
	PrOpenPage((TPrPort*)gc.win,NULL);
	gc.xoffset = (*prhandle)->prInfo.rPage.left;
	gc.yoffset = (*prhandle)->prInfo.rPage.top;
   	gc.parent.width = (*prhandle)->prInfo.rPage.right - gc.xoffset ;
	gc.parent.height = (*prhandle)->prInfo.rPage.bottom - gc.yoffset ;
	gc.parent.half_text_height = 6;
	gc.parent.line = (line_t)mac_line;
	gc.parent.out_text = (out_text_t)mac_out_text;
	gc.parent.clear_display = (clear_display_t)mac_clear_display;
	gc.parent.flush = (flush_t)mac_flush;

    	draw_graph((graphics_context *)(&gc),dd->parent.parms,dd->parent.run);
	PrClosePage((TPrPort*)gc.win);
	PrCloseDoc((TPrPort*)gc.win);
	PrClose();

}

static void fixmacfile(char* filename)
{
	FInfo  fndrinfo;
	char filename1[100];
	char filename2[100];

	strcpy(filename1,filename);
	strcpy(filename2,filename);
	GetFInfo(CtoPstr(filename1),0,&fndrinfo);
	fndrinfo.fdType='TEXT';
	fndrinfo.fdCreator='vgrd';
	SetFInfo(CtoPstr(filename2),0,&fndrinfo);
}


static char* mac_get_save_filename(mac_display_data *dd,char *title,char* def)
{
	StandardFileReply sfr;
	unsigned char *tmp, *tmp1;
	char buffer[100];

	tmp = c_to_p(def);
	tmp1 = c_to_p("Enter File Name to save as");
	StandardPutFile(tmp1,tmp,&sfr);
	free(tmp);
	free(tmp1);
	if (sfr.sfGood == FALSE)
		return NULL;
	tmp = sfr.sfFile.name;
	strncpy(buffer,(void*)(tmp + 1),tmp[0]);
	buffer[tmp[0]] = 0;
	dd->filename = (char*)strdup(buffer);
	return ((char*)strdup(buffer));
}

static void mac_enable_menuitem(mac_display_data *dd,menuitem *m)
{
	m->enabled = TRUE;
	enable_disable_menus(dd->parent.app_menu);	
}

static void change_menuitem_text(mac_display_data *dd,menuitem *m)
{
	int i,j;
	menubar *app_menu = dd->parent.app_menu;
	MenuHandle mh;
	unsigned char * tmp;

	for ( i = 0 ; i < app_menu->num_menus ; i++ ) {
		for ( j = 0 ; j < app_menu->menus[i].num_items ; j++) {
			if ( &(app_menu->menus[i].items[j]) == m)
				break;
		}
		if ( &(app_menu->menus[i].items[j]) == m)
			break;
	}
	mh = GetMenuHandle(i+1);
	tmp = c_to_p(m->label);
	SetMenuItemText(mh,j+1,tmp);
	free(tmp);
}

static void setup_callbacks(mac_display_data *dd)
{
	dd->parent.rand= (rand_t)mac_rand;
	dd->parent.create_main_window = (create_main_window_t)mac_create_main_window;
	dd->parent.start = (start_t)mac_start;
	dd->parent.get_parms=(get_parms_t)mac_get_parms;
	dd->parent.enable_menuitem = (enable_menuitem_t)mac_enable_menuitem;
	dd->parent.change_menuitem_text = (change_menuitem_text_t)change_menuitem_text;
	dd->parent.get_user_input = (get_user_input_t)mac_get_user_input;
	dd->parent.get_save_file_name = (get_save_file_name_t)mac_get_save_filename;
	dd->parent.show_message = (show_message_t)mac_show_message;
	dd->parent.print = (print_t)mac_print;
}

display_data* init_ui(int argc,char **argv)
{ 
	mac_display_data *dd;

	InitGraf(&(qd.thePort));
	InitFonts();
	InitWindows();
	InitCursor();
	InitMenus();
	InitDialogs(NULL);
	TEInit();

	dd = calloc(1,sizeof(mac_display_data));
	dd->parm_dialog=NULL;
	dd->filename=NULL;
	setup_callbacks(dd);

	srand(time(NULL));

	return (display_data *)dd;
}
